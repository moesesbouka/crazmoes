// FB Marketplace Importer - Page Context GraphQL Interceptor
// Captures listing data from Facebook's internal GraphQL responses
(function () {
  try {
    if (window.__fbImporterInjected) return;
    window.__fbImporterInjected = true;

    function emit(payload) {
      try {
        window.postMessage({ __FBIMP__: true, ...payload }, "*");
      } catch {}
    }

    function cleanJsonText(t) {
      if (!t) return "";
      let s = String(t).trim();
      if (s.startsWith("for(;;);")) s = s.slice(8);
      if (s.startsWith("for (;;);")) s = s.slice("for (;;);".length);
      return s.trim();
    }

    function safeParseAny(text) {
      const t = cleanJsonText(text);
      if (!t) return null;
      try { return JSON.parse(t); } catch {}
      const lines = t.split("\n").filter(Boolean);
      if (lines.length <= 1) return null;
      const arr = [];
      for (const line of lines) {
        try { arr.push(JSON.parse(line)); } catch {}
      }
      return arr.length ? arr : null;
    }

    function extractText(field) {
      if (!field) return "";
      if (typeof field === "string") return field.trim();
      if (typeof field === "object") {
        return String(field.text || field.value || field.name || "").trim();
      }
      return "";
    }

    function findTitle(obj) {
      const fields = [obj.title, obj.name, obj.marketplace_listing_title, obj.product_title];
      for (const f of fields) {
        const t = extractText(f);
        if (t && t.length > 2) return t;
      }
      const nested = [obj.listing?.title, obj.node?.title, obj.marketplace_listing?.title];
      for (const f of nested) {
        const t = extractText(f);
        if (t && t.length > 2) return t;
      }
      return null;
    }

    function extractPrice(obj) {
      const amt = obj.listing_price?.amount ?? obj.price?.amount ?? null;
      if (typeof amt === "number") return amt;
      const txt = obj.listing_price?.formatted_amount ?? obj.price?.formatted_amount ?? obj.price ?? null;
      if (typeof txt === "string") {
        const m = txt.replace(/,/g, "").match(/(\d+(\.\d+)?)/);
        return m ? Number(m[1]) : null;
      }
      return null;
    }

    function extractImages(obj) {
      const urls = [];
      const push = (u) => {
        if (u && typeof u === "string" && u.startsWith("http") && !urls.includes(u)) urls.push(u);
      };
      push(obj.primary_listing_photo?.image?.uri);
      push(obj.primary_photo?.image?.uri);
      push(obj.image?.uri);
      const edges = obj.listing_photos?.edges || obj.photos?.edges;
      if (Array.isArray(edges)) {
        for (const e of edges) push(e?.node?.image?.uri || e?.node?.uri);
      }
      if (Array.isArray(obj.photos)) {
        for (const p of obj.photos) push(p?.image?.uri || p?.uri);
      }
      return urls;
    }

    function looksListingish(obj) {
      if (!obj || typeof obj !== "object") return false;
      const id = obj.marketplace_listing_id || obj.listing_id || obj.id;
      if (!id) return false;
      const hasTitle = !!(obj.title || obj.name || obj.marketplace_listing_title);
      const hasPrice = !!(obj.listing_price || obj.price);
      const hasPhoto = !!(obj.primary_listing_photo || obj.primary_photo || obj.photos);
      return hasTitle || hasPrice || hasPhoto;
    }

    function deepWalkCollect(root) {
      const found = [];
      const seen = new Set();
      const walk = (node, depth) => {
        if (!node || depth > 16) return;
        if (typeof node !== "object") return;
        if (seen.has(node)) return;
        seen.add(node);
        if (looksListingish(node)) found.push(node);
        if (Array.isArray(node)) {
          for (const x of node) walk(x, depth + 1);
          return;
        }
        for (const k of Object.keys(node)) walk(node[k], depth + 1);
      };
      walk(root, 0);
      return found;
    }

    function handleGraphqlText(text) {
      const parsed = safeParseAny(text);
      if (!parsed) return;
      const payloads = Array.isArray(parsed) ? parsed : [parsed];
      for (const p of payloads) {
        const nodes = deepWalkCollect(p);
        for (const n of nodes) {
          const rawId = n.marketplace_listing_id || n.listing_id || n.id;
          if (!rawId) continue;
          const id = String(rawId).match(/\d{5,}/)?.[0] || String(rawId);
          const title = findTitle(n);
          if (!title) continue;
          emit({
            kind: "listing",
            listing: {
              facebook_id: id,
              title: title,
              description: extractText(n.description) || extractText(n.redacted_description) || "",
              price: extractPrice(n),
              images: extractImages(n),
              condition: extractText(n.condition) || "",
              location: extractText(n.location?.name) || "",
              status: "active",
              listing_url: "https://www.facebook.com/marketplace/item/" + id
            }
          });
        }
      }
    }

    function isGraphqlUrl(url) {
      return String(url || "").includes("graphql");
    }

    // Hook fetch
    const _fetch = window.fetch;
    window.fetch = async function (...args) {
      const res = await _fetch.apply(this, args);
      try {
        const url = args[0] ? (typeof args[0] === "string" ? args[0] : args[0].url) : "";
        if (isGraphqlUrl(url)) {
          res.clone().text().then(handleGraphqlText).catch(() => {});
        }
      } catch {}
      return res;
    };

    // Hook XHR
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this.__url = url;
      return _open.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function (body) {
      this.addEventListener("load", function () {
        try {
          if (isGraphqlUrl(this.__url)) handleGraphqlText(this.responseText);
        } catch {}
      });
      return _send.call(this, body);
    };

    emit({ kind: "diag", msg: "GraphQL interceptor installed" });
  } catch (e) {
    console.error("Interceptor error:", e);
  }
})();
