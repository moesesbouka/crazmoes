// Facebook Marketplace Importer - Content Script v2.0
// Added: HTML scraping for descriptions on detail pages
(function() {
  "use strict";

  const state = {
    running: false,
    stopRequested: false,
    listings: new Map(),
    unique: 0,
    enriched: 0,
    startTs: 0,
    lastNewTs: 0,
    scroller: null,
    interceptorInjected: false,
    phase: "idle"
  };

  const MIN_DELAY_MS = 900;
  const MAX_DELAY_MS = 1600;
  const SCROLL_STEP_PX = 1400;
  const SCROLL_JITTER_PX = 280;
  const MAX_RUNTIME_MS = 45 * 60 * 1000;
  const NO_NEW_GRACE_MS = 3 * 60 * 1000;

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const randInt = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

  function log(msg) {
    console.log("[FB Importer v2.0] " + msg);
  }

  function isDetailPage() {
    return window.location.href.includes("/marketplace/item/");
  }

  function getListingIdFromUrl() {
    const match = window.location.href.match(/\/marketplace\/item\/(\d+)/);
    return match ? match[1] : null;
  }

  function scrapeDescriptionFromHtml() {
    const selectors = [
      'div[data-testid="marketplace_listing_description"]',
      'span[data-testid="marketplace_listing_description"]',
      'div[class*="description"]',
      'span[class*="description"]'
    ];
    
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim().length > 10) {
        return el.textContent.trim();
      }
    }

    const allDivs = document.querySelectorAll('div[dir="auto"]');
    for (const div of allDivs) {
      const text = div.textContent.trim();
      if (text.length > 50 && text.length < 5000) {
        const parent = div.parentElement;
        if (parent && !parent.closest('a[href*="/marketplace/item/"]')) {
          const hasLinks = div.querySelectorAll('a').length;
          if (hasLinks === 0 || hasLinks < 3) {
            return text;
          }
        }
      }
    }

    return null;
  }

  function scrapeConditionFromHtml() {
    const conditionLabels = ["New", "Like new", "Good", "Fair", "Poor", "Used - Like New", "Used - Good", "Used - Fair"];
    const allText = document.body.innerText;
    
    for (const cond of conditionLabels) {
      if (allText.includes("Condition") && allText.includes(cond)) {
        return cond.toLowerCase().replace(/\s+/g, "_");
      }
    }

    const spans = document.querySelectorAll('span');
    for (const span of spans) {
      const text = span.textContent.trim();
      for (const cond of conditionLabels) {
        if (text === cond || text.toLowerCase() === cond.toLowerCase()) {
          return cond.toLowerCase().replace(/\s+/g, "_");
        }
      }
    }

    return null;
  }

  function scrapeAllImagesFromHtml() {
    const images = [];
    const imgElements = document.querySelectorAll('img[src*="fbcdn"]');
    
    for (const img of imgElements) {
      const src = img.src;
      if (src && src.includes("fbcdn") && !src.includes("emoji") && !src.includes("32x32")) {
        const isLarge = img.naturalWidth > 200 || img.width > 200 || src.includes("p720x720") || src.includes("p960x960");
        if (isLarge && !images.includes(src)) {
          images.push(src);
        }
      }
    }

    return images;
  }

  function scrapeTitleFromHtml() {
    const h1 = document.querySelector('h1');
    if (h1) return h1.textContent.trim();
    
    const spans = document.querySelectorAll('span[dir="auto"]');
    for (const span of spans) {
      const text = span.textContent.trim();
      if (text.length > 10 && text.length < 200) {
        const style = window.getComputedStyle(span);
        const fontSize = parseFloat(style.fontSize);
        if (fontSize >= 20) {
          return text;
        }
      }
    }
    return null;
  }

  function scrapePriceFromHtml() {
    const pricePatterns = document.querySelectorAll('span');
    for (const span of pricePatterns) {
      const text = span.textContent.trim();
      if (text.match(/^\$[\d,]+(\.\d{2})?$/)) {
        return text.replace(/[$,]/g, "");
      }
    }
    return null;
  }

  function scrapeDetailPage() {
    const id = getListingIdFromUrl();
    if (!id) return null;

    log("Scraping detail page for listing " + id);

    const data = {
      facebook_id: id,
      title: scrapeTitleFromHtml(),
      description: scrapeDescriptionFromHtml(),
      price: scrapePriceFromHtml(),
      images: scrapeAllImagesFromHtml(),
      condition: scrapeConditionFromHtml(),
      status: "active",
      listing_url: window.location.href.split("?")[0]
    };

    log("Scraped: " + JSON.stringify({
      id: data.facebook_id,
      title: data.title?.substring(0, 30),
      hasDesc: !!data.description,
      descLen: data.description?.length || 0,
      images: data.images?.length || 0,
      condition: data.condition
    }));

    return data;
  }

  function saveToStorage() {
    const listings = Array.from(state.listings.values());
    chrome.storage.local.get(["capturedListings"], function(stored) {
      const existing = stored.capturedListings || [];
      const existingMap = {};
      existing.forEach(function(l) { existingMap[l.facebook_id] = l; });
      
      for (const l of listings) {
        const prev = existingMap[l.facebook_id] || {};
        existingMap[l.facebook_id] = {
          ...prev,
          ...l,
          description: l.description || prev.description || "",
          condition: l.condition || prev.condition || "",
          images: (l.images && l.images.length > 0) ? l.images : (prev.images || [])
        };
      }
      
      const merged = Object.values(existingMap);
      chrome.storage.local.set({ capturedListings: merged }, function() {
        log("Saved " + merged.length + " total listings to storage");
      });
    });
  }

  function injectInterceptor() {
    if (state.interceptorInjected) return;
    state.interceptorInjected = true;
    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("page-graphql-interceptor.js");
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
      log("Injected GraphQL interceptor");
    } catch (e) {
      log("Failed to inject interceptor: " + e.message);
    }
  }

  window.addEventListener("message", (ev) => {
    try {
      if (!ev.data || typeof ev.data !== "object") return;
      if (!ev.data.__FBIMP__) return;

      if (ev.data.kind === "diag") {
        log("(interceptor) " + ev.data.msg);
        return;
      }

      if (ev.data.kind === "listing" && ev.data.listing) {
        const l = ev.data.listing;
        const id = String(l.facebook_id);
        const prev = state.listings.get(id) || {};
        
        state.listings.set(id, {
          ...prev,
          facebook_id: id,
          title: l.title || prev.title || "Listing " + id,
          description: l.description || prev.description || "",
          price: String(l.price || prev.price || "0"),
          images: (l.images && l.images.length > 0) ? l.images : (prev.images || []),
          condition: l.condition || prev.condition || "",
          status: l.status || prev.status || "active",
          location: l.location || prev.location || "",
          listing_url: l.listing_url || prev.listing_url || "https://www.facebook.com/marketplace/item/" + id
        });
        
        if (!prev.facebook_id) {
          state.unique++;
          state.lastNewTs = Date.now();
        }
      }
    } catch (e) {}
  });

  function findBestScroller() {
    const candidates = [
      document.querySelector('div[role="main"]'),
      document.querySelector('div[role="feed"]'),
      document.querySelector('main'),
      document.scrollingElement,
      document.documentElement
    ].filter(Boolean);

    let best = document.documentElement;
    let bestRoom = -1;

    for (const el of candidates) {
      try {
        const st = getComputedStyle(el);
        const oy = st.overflowY;
        const room = el.scrollHeight - el.clientHeight;
        const scrollish = (oy === "auto" || oy === "scroll" || el === document.documentElement);
        if (scrollish && room > bestRoom) {
          best = el;
          bestRoom = room;
        }
      } catch (e) {}
    }
    return best;
  }

  function doScroll(el) {
    const step = SCROLL_STEP_PX + randInt(-SCROLL_JITTER_PX, SCROLL_JITTER_PX);
    if (el === document.documentElement || el === document.body || el === document.scrollingElement) {
      window.scrollTo(0, window.scrollY + step);
    } else {
      el.scrollTop = el.scrollTop + step;
    }
  }

  function collectFromDom() {
    const anchors = document.querySelectorAll('a[href*="/marketplace/item/"]');
    let added = 0;

    for (const a of anchors) {
      try {
        const url = a.href;
        const match = url.match(/\/marketplace\/item\/(\d+)/);
        if (!match) continue;
        
        const id = match[1];
        if (state.listings.has(id)) continue;

        const title = a.getAttribute("aria-label") || a.textContent?.trim() || "";
        if (!title || title.length < 3) continue;

        state.listings.set(id, {
          facebook_id: id,
          title: title.substring(0, 200),
          description: "",
          price: "0",
          images: [],
          condition: "",
          status: "active",
          location: "",
          listing_url: url.split("?")[0]
        });

        state.unique++;
        state.lastNewTs = Date.now();
        added++;
      } catch (e) {}
    }

    return added;
  }

  async function autoScrollAndScan() {
    state.running = true;
    state.stopRequested = false;
    state.listings.clear();
    state.unique = 0;
    state.startTs = Date.now();
    state.lastNewTs = Date.now();
    state.phase = "sweep";

    log("=== Starting auto-scroll scan (max 45 min) ===");
    
    injectInterceptor();
    await sleep(1000);

    state.scroller = findBestScroller();
    log("Scroller: " + (state.scroller?.tagName || "document"));

    let tick = 0;
    let lastSaveCount = 0;

    while (!state.stopRequested) {
      tick++;

      collectFromDom();

      if (tick % 15 === 0) {
        state.scroller = findBestScroller();
      }

      doScroll(state.scroller || document.documentElement);

      if (tick % 25 === 0) {
        window.scrollBy(0, -600);
        await sleep(250);
        window.scrollBy(0, 1600);
      }

      if (tick % 50 === 0) {
        window.scrollTo(0, document.body.scrollHeight);
        await sleep(500);
        window.scrollBy(0, -900);
      }

      if (tick % 10 === 0) {
        log("Tick " + tick + ": " + state.unique + " listings found");
        if (state.unique > lastSaveCount) {
          saveToStorage();
          lastSaveCount = state.unique;
        }
      }

      const now = Date.now();
      
      if (now - state.startTs > MAX_RUNTIME_MS) {
        log("Stopping: max runtime (45 min)");
        break;
      }

      if (state.unique > 0 && now - state.lastNewTs > NO_NEW_GRACE_MS) {
        log("Stopping: no new listings for 3 minutes");
        break;
      }

      await sleep(randInt(MIN_DELAY_MS, MAX_DELAY_MS));
    }

    state.running = false;
    state.phase = "idle";
    
    saveToStorage();
    
    window.scrollTo(0, 0);

    const results = Array.from(state.listings.values());
    log("=== COMPLETE: " + results.length + " listings ===");

    return results;
  }

  function handleDetailPageScrape() {
    if (!isDetailPage()) return;
    
    setTimeout(() => {
      const data = scrapeDetailPage();
      if (data && data.facebook_id) {
        const prev = state.listings.get(data.facebook_id) || {};
        state.listings.set(data.facebook_id, {
          ...prev,
          ...data,
          description: data.description || prev.description,
          condition: data.condition || prev.condition,
          images: (data.images && data.images.length > 0) ? data.images : prev.images
        });
        
        saveToStorage();
        
        window.postMessage({
          __FBIMP__: true,
          kind: "enriched",
          listing: state.listings.get(data.facebook_id)
        }, "*");
      }
    }, 2000);
  }

  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "scanPage") {
      injectInterceptor();
      collectFromDom();
      if (isDetailPage()) {
        handleDetailPageScrape();
      }
      const listings = Array.from(state.listings.values());
      log("Quick scan: " + listings.length + " listings");
      sendResponse({ listings: listings });
    }
    if (request.action === "autoScanPage") {
      autoScrollAndScan().then(function(listings) {
        sendResponse({ listings: listings });
      });
      return true;
    }
    if (request.action === "scrapeCurrentPage") {
      const data = scrapeDetailPage();
      sendResponse({ listing: data });
    }
    return true;
  });

  log("FB Marketplace Importer v2.0 ready");
  log("Now with HTML scraping for descriptions!");
  injectInterceptor();
  
  if (isDetailPage()) {
    log("Detected detail page - scraping...");
    handleDetailPageScrape();
  }
})();
