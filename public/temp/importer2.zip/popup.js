document.addEventListener("DOMContentLoaded", function() {
  var apiUrlInput = document.getElementById("apiUrl");
  var accountTagInput = document.getElementById("accountTag");
  var syncBtn = document.getElementById("syncBtn");
  var scanBtn = document.getElementById("scanBtn");
  var autoScanBtn = document.getElementById("autoScanBtn");
  var enrichBtn = document.getElementById("enrichBtn");
  var clearBtn = document.getElementById("clearBtn");
  var statusDiv = document.getElementById("statusDiv");
  var progressDiv = document.getElementById("progressDiv");
  var capturedCountEl = document.getElementById("capturedCount");
  var enrichedCountEl = document.getElementById("enrichedCount");
  var syncedCountEl = document.getElementById("syncedCount");

  var enrichmentRunning = false;
  var enrichmentStop = false;

  chrome.storage.local.get(["apiUrl", "accountTag", "capturedListings", "syncedCount"], function(stored) {
    if (stored.apiUrl) apiUrlInput.value = stored.apiUrl;
    if (stored.accountTag) accountTagInput.value = stored.accountTag;
    updateCounts(stored.capturedListings || []);
    syncedCountEl.textContent = stored.syncedCount || 0;
  });

  function updateCounts(listings) {
    capturedCountEl.textContent = listings.length;
    var withDesc = listings.filter(function(l) {
      return l.description && l.description.length > 10;
    }).length;
    enrichedCountEl.textContent = withDesc;
  }

  function refreshCounts() {
    chrome.storage.local.get(["capturedListings", "syncedCount"], function(stored) {
      updateCounts(stored.capturedListings || []);
      syncedCountEl.textContent = stored.syncedCount || 0;
    });
  }

  apiUrlInput.addEventListener("change", function() {
    chrome.storage.local.set({ apiUrl: apiUrlInput.value });
  });

  accountTagInput.addEventListener("change", function() {
    chrome.storage.local.set({ accountTag: accountTagInput.value });
  });

  autoScanBtn.addEventListener("click", function() {
    autoScanBtn.disabled = true;
    showStatus("Auto-scrolling and scanning... Please wait", "info");
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (!tabs[0].url.includes("facebook.com/marketplace")) {
        showStatus("Please go to Facebook Marketplace first", "error");
        autoScanBtn.disabled = false;
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, { action: "autoScanPage" }, function(response) {
        autoScanBtn.disabled = false;
        if (chrome.runtime.lastError) {
          showStatus("Error: Refresh the Facebook page and try again", "error");
          return;
        }
        if (response && response.listings && response.listings.length > 0) {
          chrome.storage.local.get(["capturedListings"], function(stored) {
            var existing = stored.capturedListings || [];
            var existingIds = {};
            existing.forEach(function(l) { existingIds[l.facebook_id] = true; });
            var newListings = response.listings.filter(function(l) { return !existingIds[l.facebook_id]; });
            var merged = existing.concat(newListings);
            chrome.storage.local.set({ capturedListings: merged });
            updateCounts(merged);
            showStatus("Found " + response.listings.length + " total, " + newListings.length + " new!", "success");
          });
        } else {
          showStatus("No listings found on this page", "info");
        }
      });
    });
  });

  scanBtn.addEventListener("click", function() {
    showStatus("Scanning visible listings...", "info");
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (!tabs[0].url.includes("facebook.com/marketplace")) {
        showStatus("Please go to Facebook Marketplace first", "error");
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, { action: "scanPage" }, function(response) {
        if (chrome.runtime.lastError) {
          showStatus("Error: Refresh the Facebook page and try again", "error");
          return;
        }
        if (response && response.listings && response.listings.length > 0) {
          chrome.storage.local.get(["capturedListings"], function(stored) {
            var existing = stored.capturedListings || [];
            var existingIds = {};
            existing.forEach(function(l) { existingIds[l.facebook_id] = true; });
            var newListings = response.listings.filter(function(l) { return !existingIds[l.facebook_id]; });
            var merged = existing.concat(newListings);
            chrome.storage.local.set({ capturedListings: merged });
            updateCounts(merged);
            showStatus("Found " + response.listings.length + " listings, " + newListings.length + " new", "success");
          });
        } else {
          showStatus("No listings found. Try scrolling first.", "info");
        }
      });
    });
  });

  enrichBtn.addEventListener("click", async function() {
    if (enrichmentRunning) {
      enrichmentStop = true;
      enrichBtn.textContent = "Stopping...";
      return;
    }

    enrichmentRunning = true;
    enrichmentStop = false;
    enrichBtn.textContent = "Stop Enrichment";
    showStatus("Enriching listings (opening detail pages)...", "info");

    try {
      var stored = await chrome.storage.local.get(["capturedListings"]);
      var listings = stored.capturedListings || [];

      var needsEnrich = listings.filter(function(l) {
        var hasDesc = l.description && l.description.length > 10;
        var hasMultipleImages = l.images && l.images.length > 1;
        return !hasDesc || !hasMultipleImages;
      });

      if (needsEnrich.length === 0) {
        showStatus("All listings already enriched!", "success");
        resetEnrichButton();
        return;
      }

      progressDiv.textContent = "0 / " + needsEnrich.length + " enriched";

      for (var i = 0; i < needsEnrich.length; i++) {
        if (enrichmentStop) {
          showStatus("Enrichment stopped", "info");
          break;
        }

        var listing = needsEnrich[i];
        var url = listing.listing_url || ("https://www.facebook.com/marketplace/item/" + listing.facebook_id + "/");

        progressDiv.textContent = (i + 1) + " / " + needsEnrich.length + ": " + (listing.title || "").substring(0, 25) + "...";

        try {
          var tab = await chrome.tabs.create({ url: url, active: false });
          
          await new Promise(function(resolve) { setTimeout(resolve, 3500); });

          try {
            await chrome.tabs.sendMessage(tab.id, { action: "scrapeCurrentPage" });
          } catch (e) {}

          await new Promise(function(resolve) { setTimeout(resolve, 500); });

          try {
            await chrome.tabs.remove(tab.id);
          } catch (e) {}
        } catch (e) {
          console.error("Error enriching listing:", e);
        }

        refreshCounts();

        await new Promise(function(resolve) { setTimeout(resolve, 500); });
      }

      refreshCounts();
      showStatus("Enrichment complete!", "success");
      progressDiv.textContent = "";

    } catch (e) {
      showStatus("Enrichment error: " + e.message, "error");
    }

    resetEnrichButton();
  });

  function resetEnrichButton() {
    enrichmentRunning = false;
    enrichmentStop = false;
    enrichBtn.textContent = "Enrich Listings (Get Descriptions)";
  }

  syncBtn.addEventListener("click", function() {
    var apiUrl = apiUrlInput.value.trim();
    if (!apiUrl) {
      showStatus("Please enter your dashboard URL", "error");
      return;
    }
    syncBtn.disabled = true;
    showStatus("Syncing to dashboard...", "info");
    chrome.storage.local.get(["capturedListings", "syncedCount"], function(stored) {
      var listings = stored.capturedListings || [];
      if (listings.length === 0) {
        showStatus("No listings to sync. Scan first.", "info");
        syncBtn.disabled = false;
        return;
      }
      var accountTag = accountTagInput.value.trim() || "default";
      var taggedListings = listings.map(function(l) {
        l.account_tag = accountTag;
        return l;
      });
      fetch(apiUrl + "/api/listings/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ listings: taggedListings })
      })
      .then(function(response) {
        if (!response.ok) throw new Error("Failed to sync");
        return response.json();
      })
      .then(function(result) {
        var newCount = (stored.syncedCount || 0) + listings.length;
        chrome.storage.local.set({ capturedListings: [], syncedCount: newCount });
        capturedCountEl.textContent = 0;
        enrichedCountEl.textContent = 0;
        syncedCountEl.textContent = newCount;
        showStatus("Success! " + result.inserted + " new, " + result.updated + " updated", "success");
      })
      .catch(function(err) {
        showStatus("Sync failed: " + err.message, "error");
      })
      .finally(function() {
        syncBtn.disabled = false;
      });
    });
  });

  clearBtn.addEventListener("click", function() {
    if (!confirm("Clear all captured listings?")) return;
    chrome.storage.local.set({ capturedListings: [] });
    capturedCountEl.textContent = 0;
    enrichedCountEl.textContent = 0;
    showStatus("Cleared all captured listings", "info");
  });

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = "status " + type;
  }
});
