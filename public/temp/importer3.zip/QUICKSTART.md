# Quick Start Guide

Get your Crosslist Clone up and running in 5 minutes!

## Prerequisites
- Docker & Docker Compose installed
- Basic terminal knowledge

## Step 1: Clone & Setup

```bash
# Clone the repository
git clone <your-repo-url>
cd crosslist-clone

# Copy environment files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

## Step 2: Configure (Optional)

Edit `backend/.env` if you want to add Facebook/Mercari credentials:

```bash
nano backend/.env
```

For now, you can leave them blank and add them later.

## Step 3: Start the Application

```bash
docker-compose up -d
```

Wait 30-60 seconds for containers to start.

## Step 4: Access the Application

- **Frontend**: http://localhost:5173
- **API Docs**: http://localhost:8000/docs

## Step 5: Create Your First Listing

1. Click "Create Listing" on the dashboard
2. Enter a title and price (required fields)
3. Add description and other details if desired
4. Upload images (optional)
5. Click "Create Listing"

## Step 6: Try Bulk Import

1. Download the template from "Bulk Import"
2. Edit the CSV file with your listings
3. Upload the file
4. See your listings appear!

## Step 7: Post to Marketplaces

1. Go to "Manage Listings"
2. Find your listing
3. Click "Post" next to Facebook or Mercari
4. The listing will be posted to the selected marketplace

## Troubleshooting

### Application not loading?
```bash
# Check if containers are running
docker-compose ps

# View logs
docker-compose logs
```

### Database connection error?
```bash
# Restart containers
docker-compose down
docker-compose up -d
```

### Port already in use?
Edit `docker-compose.yml` to use different ports:
```yaml
ports:
  - "8001:8000"  # Change 8000 to 8001
```

## Next Steps

1. **Configure Facebook Integration**: Add your Facebook credentials to enable posting
2. **Configure Mercari Integration**: Add Mercari API keys
3. **Set Up Production**: Follow deployment guide for Namecheap hosting
4. **Back Up Data**: Set up regular database backups

## Stopping the Application

```bash
# Stop containers
docker-compose down

# Stop and remove volumes (WARNING: deletes data)
docker-compose down -v
```

---

**Need help?** Check the full README.md for detailed documentation