# API Documentation

Complete API reference for the Crosslist Clone backend.

## Base URL

```
http://localhost:8000/api/v1
```

## Authentication

Currently, this API does not require authentication for in-house use.

## Response Format

All responses follow this format:

**Success Response:**
```json
{
  "data": {},
  "message": "Success message"
}
```

**Error Response:**
```json
{
  "detail": "Error message"
}
```

## Endpoints

### Listings

#### Get All Listings

```http
GET /listings
```

**Query Parameters:**
- `skip` (integer, optional): Number of records to skip (default: 0)
- `limit` (integer, optional): Number of records to return (default: 100)
- `active_only` (boolean, optional): Return only active listings (default: true)

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/listings?skip=0&limit=50&active_only=true"
```

**Example Response:**
```json
[
  {
    "id": 1,
    "title": "Vintage Camera",
    "description": "A beautiful vintage camera in excellent condition",
    "price": 199.99,
    "quantity": 1,
    "category": "Electronics",
    "condition": "Good",
    "sku": "CAM-001",
    "tags": ["vintage", "camera", "electronics"],
    "notes": "Original box included",
    "images": ["uploads/2024/01/15/abc123.jpg"],
    "facebook_listing_id": null,
    "mercari_listing_id": null,
    "is_active": true,
    "posted_to_facebook": false,
    "posted_to_mercari": false,
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00",
    "last_synced": null
  }
]
```

#### Get Single Listing

```http
GET /listings/{listing_id}
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/listings/1"
```

**Example Response:**
```json
{
  "id": 1,
  "title": "Vintage Camera",
  "description": "A beautiful vintage camera in excellent condition",
  "price": 199.99,
  "quantity": 1,
  "category": "Electronics",
  "condition": "Good",
  "sku": "CAM-001",
  "tags": ["vintage", "camera", "electronics"],
  "notes": "Original box included",
  "images": ["uploads/2024/01/15/abc123.jpg"],
  "facebook_listing_id": null,
  "mercari_listing_id": null,
  "is_active": true,
  "posted_to_facebook": false,
  "posted_to_mercari": false,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T10:30:00",
  "last_synced": null
}
```

#### Create Listing

```http
POST /listings
```

**Request Body:**
```json
{
  "title": "Vintage Camera",
  "description": "A beautiful vintage camera in excellent condition",
  "price": 199.99,
  "quantity": 1,
  "category": "Electronics",
  "condition": "Good",
  "sku": "CAM-001",
  "tags": ["vintage", "camera", "electronics"],
  "notes": "Original box included",
  "images": [],
  "post_to_facebook": false,
  "post_to_mercari": false
}
```

**Required Fields:**
- `title` (string, min: 5, max: 255)
- `price` (float, > 0)

**Optional Fields:**
- `description` (string)
- `quantity` (integer, default: 1, min: 1)
- `category` (string)
- `condition` (string, enum: ["New", "Like New", "Good", "Fair", "Poor"])
- `sku` (string)
- `tags` (array of strings)
- `notes` (string)
- `images` (array of strings)
- `post_to_facebook` (boolean, default: false)
- `post_to_mercari` (boolean, default: false)

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/listings" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Vintage Camera",
    "description": "A beautiful vintage camera in excellent condition",
    "price": 199.99,
    "quantity": 1,
    "category": "Electronics",
    "condition": "Good",
    "post_to_facebook": true
  }'
```

**Example Response:**
```json
{
  "id": 1,
  "title": "Vintage Camera",
  "description": "A beautiful vintage camera in excellent condition",
  "price": 199.99,
  "quantity": 1,
  "category": "Electronics",
  "condition": "Good",
  "sku": null,
  "tags": [],
  "notes": null,
  "images": [],
  "facebook_listing_id": "fb_12345",
  "mercari_listing_id": null,
  "is_active": true,
  "posted_to_facebook": true,
  "posted_to_mercari": false,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T10:30:00",
  "last_synced": "2024-01-15T10:30:05"
}
```

#### Update Listing

```http
PUT /listings/{listing_id}
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing

**Request Body:** (All fields optional)
```json
{
  "title": "Updated Title",
  "description": "Updated description",
  "price": 249.99,
  "quantity": 2,
  "is_active": false
}
```

**Example Request:**
```bash
curl -X PUT "http://localhost:8000/api/v1/listings/1" \
  -H "Content-Type: application/json" \
  -d '{
    "price": 249.99,
    "quantity": 2
  }'
```

**Example Response:**
```json
{
  "id": 1,
  "title": "Vintage Camera",
  "description": "A beautiful vintage camera in excellent condition",
  "price": 249.99,
  "quantity": 2,
  "category": "Electronics",
  "condition": "Good",
  "sku": null,
  "tags": [],
  "notes": null,
  "images": [],
  "facebook_listing_id": "fb_12345",
  "mercari_listing_id": null,
  "is_active": true,
  "posted_to_facebook": true,
  "posted_to_mercari": false,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T11:00:00",
  "last_synced": "2024-01-15T10:30:05"
}
```

#### Delete Listing

```http
DELETE /listings/{listing_id}
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing

**Example Request:**
```bash
curl -X DELETE "http://localhost:8000/api/v1/listings/1"
```

**Example Response:**
```json
{
  "message": "Listing deleted successfully"
}
```

### Images

#### Upload Images

```http
POST /listings/{listing_id}/upload-images
```

**Content-Type:** `multipart/form-data`

**Form Data:**
- `files` (file, required): Image files (max 24 images, max 50MB each)
- Accepts: JPEG, PNG, WEBP

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/listings/1/upload-images" \
  -F "files=@image1.jpg" \
  -F "files=@image2.png"
```

**Example Response:**
```json
{
  "message": "Uploaded 2 images",
  "images": [
    "uploads/2024/01/15/abc123.jpg",
    "uploads/2024/01/15/def456.png"
  ],
  "listing": {
    "id": 1,
    "title": "Vintage Camera",
    "images": [
      "uploads/2024/01/15/abc123.jpg",
      "uploads/2024/01/15/def456.png"
    ]
  }
}
```

#### Delete Image

```http
DELETE /listings/{listing_id}/images/{image_index}
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing
- `image_index` (integer, required): The index of the image to delete (0-based)

**Example Request:**
```bash
curl -X DELETE "http://localhost:8000/api/v1/listings/1/images/0"
```

**Example Response:**
```json
{
  "message": "Image deleted successfully"
}
```

### Marketplace Posting

#### Post to Facebook Marketplace

```http
POST /listings/{listing_id}/post-to-facebook
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/listings/1/post-to-facebook"
```

**Example Response:**
```json
{
  "success": true,
  "listing_id": "fb_12345",
  "message": "Listing posted successfully"
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Facebook credentials not configured"
}
```

#### Post to Mercari

```http
POST /listings/{listing_id}/post-to-mercari
```

**Path Parameters:**
- `listing_id` (integer, required): The ID of the listing

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/listings/1/post-to-mercari"
```

**Example Response:**
```json
{
  "success": true,
  "listing_id": "mercari_67890",
  "message": "Listing posted successfully"
}
```

### Import/Export

#### Import from CSV

```http
POST /import-export/import-csv
```

**Content-Type:** `multipart/form-data`

**Form Data:**
- `file` (file, required): CSV file

**CSV Format:**
```csv
title,description,price,quantity,category,condition,sku,tags,notes
"Product 1","Description",29.99,1,"Category","Good","SKU-001","tag1,tag2","Notes"
"Product 2","Description",39.99,2,"Category","New","SKU-002","tag3,tag4","Notes"
```

**Required Columns:**
- `title`
- `price`

**Optional Columns:**
- `description`
- `quantity`
- `category`
- `condition`
- `sku`
- `tags` (comma-separated)
- `notes`

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/import-export/import-csv" \
  -F "file=@listings.csv"
```

**Example Response:**
```json
{
  "success": true,
  "imported_count": 100,
  "errors": [
    "Row 15: Missing title",
    "Row 23: Invalid price format"
  ],
  "message": "Successfully imported 100 listings"
}
```

#### Import from JSON

```http
POST /import-export/import-json
```

**Content-Type:** `multipart/form-data`

**Form Data:**
- `file` (file, required): JSON file

**JSON Format:**
```json
[
  {
    "title": "Product 1",
    "description": "Description",
    "price": 29.99,
    "quantity": 1,
    "category": "Category",
    "condition": "Good",
    "sku": "SKU-001",
    "tags": ["tag1", "tag2"],
    "notes": "Notes"
  },
  {
    "title": "Product 2",
    "description": "Description",
    "price": 39.99,
    "quantity": 2,
    "category": "Category",
    "condition": "New",
    "sku": "SKU-002",
    "tags": ["tag3", "tag4"],
    "notes": "Notes"
  }
]
```

**Required Fields:**
- `title`
- `price`

**Optional Fields:**
- `description`
- `quantity`
- `category`
- `condition`
- `sku`
- `tags`
- `notes`

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/import-export/import-json" \
  -F "file=@listings.json"
```

**Example Response:**
```json
{
  "success": true,
  "imported_count": 50,
  "errors": [],
  "message": "Successfully imported 50 listings"
}
```

#### Export to CSV

```http
GET /import-export/export-csv
```

**Query Parameters:**
- `active_only` (boolean, optional): Export only active listings (default: true)

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/import-export/export-csv?active_only=true" \
  -o listings.csv
```

**Response:** CSV file download

#### Export to JSON

```http
GET /import-export/export-json
```

**Query Parameters:**
- `active_only` (boolean, optional): Export only active listings (default: true)

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/import-export/export-json?active_only=true" \
  -o listings.json
```

**Response:** JSON file download

## Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 404 | Not Found |
| 422 | Validation Error |
| 500 | Internal Server Error |

## Rate Limiting

Currently, there are no rate limits for in-house use.

## Interactive API Documentation

FastAPI provides interactive API documentation:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

These interfaces allow you to:
- Explore all endpoints
- Test API calls directly
- View request/response schemas
- Download OpenAPI specification

## Webhook Support

Currently, webhooks are not implemented but can be added for:
- Sold notifications
- Price change alerts
- Inventory updates

## Versioning

API versioning is handled through the URL path:
- Current version: `/api/v1`
- Future versions: `/api/v2`, etc.

---

For support or questions, refer to the main README.md file.