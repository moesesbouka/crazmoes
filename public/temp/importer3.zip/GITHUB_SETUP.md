# GitHub Setup Guide for Beginners

Complete step-by-step guide to set up GitHub automation for your Crosslist clone.

## 📋 What This Guide Covers

✅ Create GitHub repository  
✅ Push your code to GitHub  
✅ Set up GitHub Actions secrets  
✅ Enable automated deployments  
✅ Configure automated backups  
✅ Set up health monitoring  
✅ Enable automatic updates  

---

## 🚀 STEP 1: Create GitHub Account

1. Go to https://github.com
2. Click "Sign up"
3. Fill in your information
4. Verify your email

**Already have an account?** Skip to Step 2.

---

## 📦 STEP 2: Create Repository

1. **Log in to GitHub**
2. **Click the + button** (top right corner)
3. **Select "New repository"**
4. **Fill in repository details:**
   - Repository name: `crosslist-clone` (or any name you want)
   - Description: `Multi-marketplace listing manager`
   - Make it **Private** (recommended for your in-house app)
   - **Do NOT** initialize with README (we already have one)
5. **Click "Create repository"**

You'll see a page with instructions like:
```
…or push an existing repository from the command line
git remote add origin https://github.com/YOUR_USERNAME/crosslist-clone.git
git branch -M main
git push -u origin main
```

**Copy these commands** - you'll need them!

---

## 🔑 STEP 3: Set Up SSH Keys (One-Time Setup)

This allows GitHub to securely communicate with your server.

### On Your Local Computer:

1. **Generate SSH key:**
```bash
ssh-keygen -t ed25519 -C "your-email@example.com"
```
Press Enter for all prompts (use default settings)

2. **Copy the public key:**
```bash
cat ~/.ssh/id_ed25519.pub
```

3. **Add to GitHub:**
   - Go to GitHub → Settings → SSH and GPG keys
   - Click "New SSH key"
   - Title: "Namecheap Server" (or any name)
   - Key: Paste the output from step 2
   - Click "Add SSH key"

### On Your Namecheap Server:

1. **Generate SSH key on server:**
```bash
ssh user@your-domain.com
ssh-keygen -t ed25519 -C "your-email@example.com"
```

2. **Copy the public key:**
```bash
cat ~/.ssh/id_ed25519.pub
```

3. **Add to GitHub:**
   - Go to GitHub → Settings → SSH and GPG keys
   - Click "New SSH key"
   - Title: "Production Server"
   - Key: Paste the output from step 2
   - Click "Add SSH key"

---

## 📤 STEP 4: Push Your Code to GitHub

### On Your Local Computer:

1. **Navigate to your project folder:**
```bash
cd path/to/crosslist-clone
```

2. **Initialize Git repository:**
```bash
git init
```

3. **Add all files:**
```bash
git add .
```

4. **Create first commit:**
```bash
git commit -m "Initial commit - Crosslist clone"
```

5. **Add GitHub as remote:**
```bash
git remote add origin https://github.com/YOUR_USERNAME/crosslist-clone.git
```
*(Replace YOUR_USERNAME with your actual GitHub username)*

6. **Push to GitHub:**
```bash
git branch -M main
git push -u origin main
```

7. **Enter your GitHub credentials** when prompted

### If You Get Errors:

**Error: "fatal: remote origin already exists"**
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/crosslist-clone.git
git push -u origin main
```

**Error: "Authentication failed"**
- Make sure you're using your GitHub username and password
- Or use a Personal Access Token (recommended):
  1. GitHub → Settings → Developer settings → Personal access tokens
  2. Generate new token (classic)
  3. Select: repo, workflow
  4. Use token as password when pushing

---

## 🔐 STEP 5: Set Up GitHub Actions Secrets

These secrets allow GitHub to securely access your server.

### Get Your Server Information:

1. **Server host:** Your domain (e.g., `your-domain.com`) or IP address
2. **Server user:** Your SSH username (e.g., `root` or your username)
3. **SSH private key:** Copy from your local computer

**To copy SSH private key:**
```bash
cat ~/.ssh/id_ed25519
```
*(Copy everything including `-----BEGIN OPENSSH PRIVATE KEY-----` and `-----END OPENSSH PRIVATE KEY-----`)*

### Add Secrets to GitHub:

1. **Go to your repository** on GitHub
2. **Click "Settings"** tab
3. **Click "Secrets and variables"** → "Actions"
4. **Click "New repository secret"**
5. **Add these secrets one by one:**

| Secret Name | Value |
|------------|-------|
| `SERVER_HOST` | Your domain or IP (e.g., `your-domain.com`) |
| `SERVER_USER` | Your SSH username (e.g., `root` or `user`) |
| `SSH_PRIVATE_KEY` | Your private SSH key (paste everything) |

6. **Click "Add secret"** for each one

### Verify Secrets:

You should see 3 secrets listed:
- ✅ SERVER_HOST
- ✅ SERVER_USER
- ✅ SSH_PRIVATE_KEY

---

## 🤖 STEP 6: Enable GitHub Actions

The workflows are already created in `.github/workflows/`:
- `deploy.yml` - Automatic deployment
- `health-check.yml` - Health monitoring
- `backup.yml` - Automated backups
- `auto-update.yml` - Docker updates

### Verify Workflows Exist:

1. **Go to your repository** on GitHub
2. **Click "Actions"** tab
3. **You should see:**
   - Deploy to Production
   - Health Check
   - Automated Backup
   - Auto Update Docker Images

### Test Deployment Manually:

1. **Click "Deploy to Production"** workflow
2. **Click "Run workflow"** button
3. **Click "Run workflow"** green button
4. **Watch the progress** in the "Actions" tab

---

## ✅ STEP 7: Test Automated Deployment

Now let's make sure everything works!

1. **Make a small change** to your code:
```bash
# Example: Edit a file
nano README.md
# Add a line like: "Testing GitHub Actions - [your date]"
```

2. **Commit and push:**
```bash
git add README.md
git commit -m "Test automated deployment"
git push
```

3. **Watch it deploy:**
   - Go to GitHub → Actions tab
   - You should see "Deploy to Production" running
   - Wait for it to complete (green checkmark = success!)

4. **Verify your server:**
```bash
ssh user@your-domain.com
docker-compose -f /var/www/crosslist/docker-compose.yml ps
```

All containers should be running!

---

## 🔄 STEP 8: Automated Workflows Explained

### Deploy to Production
- **When:** Every time you push to `main` branch
- **What:** Pulls latest code, rebuilds, restarts containers
- **How often:** As often as you push changes

### Health Check
- **When:** Every 30 minutes automatically
- **What:** Checks if backend, frontend, and database are healthy
- **What if fails:** Restarts failed services and creates GitHub issue

### Automated Backup
- **When:** Daily at 3 AM UTC (adjustable)
- **What:** Backs up database and images
- **Where:** Saves to server and GitHub (30-day retention)

### Auto Update Docker Images
- **When:** Daily at 4 AM UTC (adjustable)
- **What:** Checks for Docker image updates and updates them
- **Safety:** Performs health check after update, rolls back if needed

---

## 📊 STEP 9: Monitor Your Automations

### View Workflow Runs:

1. **Go to GitHub** → Your repository
2. **Click "Actions"** tab
3. **See all workflow runs:**
   - ✅ Green = Success
   - ❌ Red = Failed
   - 🟡 Yellow = In progress

### View Workflow Logs:

1. **Click on a workflow run**
2. **Click on the job name** (e.g., "deploy")
3. **See detailed logs** of what happened

### Get Notifications:

1. **Go to repository** → Settings → Notifications
2. **Choose how you want to be notified:**
   - Email
   - GitHub mobile app
   - Web (in GitHub)

---

## 🛠️ STEP 10: Customize Schedules (Optional)

Want backups at different times? Edit the schedule in each workflow:

### Example: Change backup time to 5 PM UTC:

1. **Edit `.github/workflows/backup.yml`**
2. **Find this line:**
```yaml
schedule:
  - cron: '0 3 * * *'  # 3 AM UTC
```
3. **Change to:**
```yaml
schedule:
  - cron: '0 17 * * *'  # 5 PM UTC
```
4. **Commit and push:**
```bash
git add .github/workflows/backup.yml
git commit -m "Change backup time to 5 PM UTC"
git push
```

### Cron Schedule Format:
```
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of week (0 - 6) (Sunday = 0)
* * * * *
```

Examples:
- `0 2 * * *` - Every day at 2 AM UTC
- `*/30 * * * *` - Every 30 minutes
- `0 */6 * * *` - Every 6 hours
- `0 0 * * 0` - Every Sunday at midnight

---

## 🆘 Troubleshooting

### GitHub Actions Failures:

**Error: "Permission denied (publickey)"**
- Make sure SSH_PRIVATE_KEY secret is correct
- Verify the key format (include BEGIN/END lines)
- Regenerate keys if needed

**Error: "Could not resolve hostname"**
- Check SERVER_HOST secret
- Try using IP address instead of domain
- Verify DNS settings

**Error: "Connection refused"**
- Make sure server is online
- Check firewall settings (port 22 must be open)
- Verify SSH is running on server

### Deployment Not Triggering:

**Push didn't trigger deployment**
- Make sure you're pushing to `main` branch
- Check workflow file exists in `.github/workflows/`
- Verify workflow YAML syntax is correct

**Deployment runs but doesn't update**
- Check if docker-compose.yml exists on server
- Verify file permissions
- Check logs for specific errors

### Health Check Fails:

**Services show as unhealthy**
- Check server logs: `docker-compose logs`
- Restart services: `docker-compose restart`
- Verify all secrets are configured correctly

---

## 📝 Quick Reference Commands

### On Your Local Computer:
```bash
# Push changes
git add .
git commit -m "Your message"
git push

# Check status
git status

# View logs
git log --oneline
```

### On Your Server:
```bash
# Check containers
docker-compose ps

# View logs
docker-compose logs -f

# Restart services
docker-compose restart

# Manual backup
~/backup_crosslist.sh

# Check health
~/health_check.sh
```

---

## 🎉 You're All Set!

Now you have:

✅ **Automated Deployments** - Push code, it deploys automatically  
✅ **Automated Backups** - Backups run daily automatically  
✅ **Health Monitoring** - Checks every 30 minutes  
✅ **Auto Updates** - Docker images update automatically  
✅ **Notifications** - Get alerts if something goes wrong  

### Your Workflow Now:

1. **Make changes** to your code locally
2. **Commit and push** to GitHub
3. **GitHub Actions** automatically deploys to your server
4. **Everything runs** automatically in the background
5. **Get notified** if something goes wrong

---

## 📚 Additional Resources

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [GitHub Secrets Documentation](https://docs.github.com/en/actions/security-guides/encrypted-secrets)
- [Cron Schedule Helper](https://crontab.guru/)

---

## 💡 Pro Tips

1. **Test workflows manually first** before relying on automation
2. **Keep secrets secure** - never commit them to your repository
3. **Monitor workflow runs** regularly to catch issues early
4. **Use descriptive commit messages** for better tracking
5. **Set up email notifications** so you never miss important updates

---

**Questions?** Check the main README.md or DEPLOYMENT.md for more detailed information.