"""
Utils package initialization
"""