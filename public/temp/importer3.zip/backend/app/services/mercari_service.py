"""
Mercari integration service
"""
import httpx
from typing import Dict, List, Optional
from app.config import settings
from datetime import datetime

class MercariService:
    """
    Service for interacting with Mercari API
    Note: Mercari has limited official API access.
    This implementation provides a framework for integration.
    """
    
    BASE_URL = "https://api.mercari.com/v2"
    
    def __init__(self):
        self.api_key = settings.MERCARI_API_KEY
        self.user_id = settings.MERCARI_USER_ID
    
    async def post_listing(self, listing_data: Dict) -> Dict:
        """
        Post a listing to Mercari
        """
        if not self.api_key:
            return {
                "success": False,
                "error": "Mercari API key not configured"
            }
        
        try:
            payload = self._prepare_listing_payload(listing_data)
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.BASE_URL}/items",
                    json=payload,
                    headers=headers
                )
            
            if response.status_code in [200, 201]:
                result = response.json()
                return {
                    "success": True,
                    "listing_id": result.get("id"),
                    "message": "Listing posted successfully"
                }
            else:
                return {
                    "success": False,
                    "error": response.text
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def update_listing(self, listing_id: str, listing_data: Dict) -> Dict:
        """
        Update an existing Mercari listing
        """
        if not self.api_key:
            return {"success": False, "error": "Mercari API key not configured"}
        
        try:
            payload = self._prepare_listing_payload(listing_data)
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.put(
                    f"{self.BASE_URL}/items/{listing_id}",
                    json=payload,
                    headers=headers
                )
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "message": "Listing updated successfully"
                }
            else:
                return {
                    "success": False,
                    "error": response.text
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def delete_listing(self, listing_id: str) -> Dict:
        """
        Delete a Mercari listing
        """
        if not self.api_key:
            return {"success": False, "error": "Mercari API key not configured"}
        
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}"
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.delete(
                    f"{self.BASE_URL}/items/{listing_id}",
                    headers=headers
                )
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "message": "Listing deleted successfully"
                }
            else:
                return {
                    "success": False,
                    "error": response.text
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def _prepare_listing_payload(self, listing_data: Dict) -> Dict:
        """
        Prepare listing data for Mercari API
        """
        payload = {
            "title": listing_data.get("title"),
            "description": listing_data.get("description"),
            "price": int(listing_data.get("price") * 100),  # Mercari uses cents
            "category": listing_data.get("category"),
            "condition": listing_data.get("condition"),
            "images": listing_data.get("images", []),
        }
        
        return payload
    
    async def get_listing(self, listing_id: str) -> Dict:
        """
        Get listing details from Mercari
        """
        if not self.api_key:
            return {"success": False, "error": "Mercari API key not configured"}
        
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}"
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.BASE_URL}/items/{listing_id}",
                    headers=headers
                )
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "data": response.json()
                }
            else:
                return {
                    "success": False,
                    "error": response.text
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }