"""
Services package initialization
"""