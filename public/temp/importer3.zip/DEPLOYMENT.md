# Deployment Guide for Namecheap Hosting

This guide will help you deploy your Crosslist Clone to Namecheap hosting.

## Prerequisites

- Namecheap hosting account (VPS or Shared Hosting with SSH access)
- Domain name pointed to your server
- SSH access to your server
- Basic knowledge of Linux commands

## Step 1: Server Preparation

### 1.1 Connect to Your Server

```bash
ssh user@your-domain.com
```

### 1.2 Update System

```bash
sudo apt update
sudo apt upgrade -y
```

### 1.3 Install Docker

```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
```

### 1.4 Install Docker Compose

```bash
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
docker-compose --version
```

### 1.5 Install Nginx

```bash
sudo apt install nginx -y
sudo systemctl start nginx
sudo systemctl enable nginx
```

## Step 2: Deploy Application

### 2.1 Clone Repository

```bash
cd /var/www
sudo git clone <your-repo-url> crosslist
sudo chown -R $USER:$USER crosslist
cd crosslist
```

### 2.2 Configure Environment

```bash
cd backend
cp .env.example .env
nano .env
```

Update the following settings:
```env
DATABASE_URL=postgresql://crosslist_user:your_secure_password@db:5432/crosslist_db
DEBUG=False
FACEBOOK_ACCESS_TOKEN=your_facebook_token
FACEBOOK_PAGE_ID=your_page_id
MERCARI_API_KEY=your_mercari_api_key
MERCARI_USER_ID=your_mercari_user_id
```

### 2.3 Update Docker Compose for Production

```bash
cd ..
nano docker-compose.yml
```

Change ports to use internal networking:
```yaml
services:
  backend:
    ports:
      - "127.0.0.1:8000:8000"  # Only accessible locally
  
  frontend:
    ports:
      - "127.0.0.1:5173:5173"  # Only accessible locally
```

### 2.4 Start Application

```bash
docker-compose up -d
```

Check if containers are running:
```bash
docker-compose ps
```

## Step 3: Configure Nginx

### 3.1 Create Nginx Configuration

```bash
sudo nano /etc/nginx/sites-available/crosslist
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Frontend
    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Backend API
    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Increase timeout for large uploads
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
        proxy_read_timeout 300;
    }

    # Uploaded images
    location /uploads {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
    }
}
```

### 3.2 Enable Site

```bash
sudo ln -s /etc/nginx/sites-available/crosslist /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Step 4: Set Up SSL with Let's Encrypt

### 4.1 Install Certbot

```bash
sudo apt install certbot python3-certbot-nginx -y
```

### 4.2 Obtain SSL Certificate

```bash
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

Follow the prompts. Choose to redirect HTTP to HTTPS.

### 4.3 Auto-Renewal Setup

```bash
sudo certbot renew --dry-run
```

(Certbot automatically sets up renewal cron job)

## Step 5: Security Hardening

### 5.1 Configure Firewall

```bash
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### 5.2 Fail2Ban (Optional but Recommended)

```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 5.3 Secure Database Password

Generate a strong password:
```bash
openssl rand -base64 32
```

Update in `backend/.env` and `docker-compose.yml`

## Step 6: Set Up Backups

### 6.1 Create Backup Script

```bash
nano /home/user/backup.sh
```

```bash
#!/bin/bash

# Backup directory
BACKUP_DIR="/home/user/backups"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

# Backup database
docker-compose exec -T db pg_dump -U crosslist_user crosslist_db > $BACKUP_DIR/db_backup_$DATE.sql

# Backup uploaded images
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz uploads/

# Keep last 7 days of backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: $DATE"
```

Make it executable:
```bash
chmod +x /home/user/backup.sh
```

### 6.2 Set Up Cron Job

```bash
crontab -e
```

Add this line for daily backups at 2 AM:
```
0 2 * * * /home/user/backup.sh >> /home/user/backup.log 2>&1
```

## Step 7: Monitoring & Logging

### 7.1 View Application Logs

```bash
# View all logs
docker-compose logs -f

# View backend logs
docker-compose logs -f backend

# View frontend logs
docker-compose logs -f frontend

# View database logs
docker-compose logs -f db
```

### 7.2 Set Up Log Rotation

```bash
sudo nano /etc/logrotate.d/docker-compose
```

```
/var/www/crosslist/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        docker-compose -f /var/www/crosslist/docker-compose.yml restart backend
    endscript
}
```

## Step 8: Performance Optimization

### 8.1 Enable Nginx Caching

Edit Nginx config:
```bash
sudo nano /etc/nginx/sites-available/crosslist
```

Add before `server` block:
```nginx
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=my_cache:10m max_size=1g 
                 inactive=60m use_temp_path=off;
```

Add in server block:
```nginx
location /static {
    proxy_cache my_cache;
    proxy_pass http://127.0.0.1:5173;
    proxy_cache_valid 200 1d;
}
```

### 8.2 Optimize PostgreSQL

```bash
docker-compose exec db psql -U crosslist_user -d crosslist_db
```

```sql
-- Create indexes for better performance
CREATE INDEX idx_listings_created_at ON listings(created_at);
CREATE INDEX idx_listings_posted_facebook ON listings(posted_to_facebook);
CREATE INDEX idx_listings_posted_mercari ON listings(posted_to_mercari);
CREATE INDEX idx_listings_is_active ON listings(is_active);
```

## Step 9: Maintenance

### 9.1 Update Application

```bash
cd /var/www/crosslist
git pull origin main
docker-compose down
docker-compose pull
docker-compose up -d --build
```

### 9.2 Clear Docker Cache

```bash
docker system prune -a
```

### 9.3 Monitor Disk Space

```bash
df -h
docker system df
```

## Troubleshooting

### Application Not Loading

```bash
# Check if containers are running
docker-compose ps

# Check logs
docker-compose logs

# Restart containers
docker-compose restart
```

### 502 Bad Gateway

```bash
# Check if Nginx is running
sudo systemctl status nginx

# Check Nginx error logs
sudo tail -f /var/log/nginx/error.log

# Restart Nginx
sudo systemctl restart nginx
```

### Database Connection Issues

```bash
# Check if database container is running
docker-compose ps db

# Check database logs
docker-compose logs db

# Restart database
docker-compose restart db
```

### SSL Certificate Issues

```bash
# Renew certificate manually
sudo certbot renew

# Check certificate status
sudo certbot certificates
```

### Port Already in Use

```bash
# Find what's using the port
sudo lsof -i :80
sudo lsof -i :443

# Kill the process if needed
sudo kill -9 <PID>
```

## Cost Optimization

### Namecheap VPS Plans

- **Stellar** ($3.98/month): Good for testing (2GB RAM)
- **Stellar Plus** ($5.98/month): Recommended (4GB RAM)
- **Stellar Business** ($11.98/month): For high traffic (8GB RAM)

### Resource Limits

Monitor usage with:
```bash
htop
docker stats
```

## Next Steps

1. **Set up monitoring**: Use tools like UptimeRobot or StatusCake
2. **Configure email notifications**: For backup failures or server issues
3. **Set up staging environment**: For testing updates
4. **Implement CI/CD**: Automated deployments
5. **Add analytics**: Track usage and performance

## Support

If you encounter issues:
1. Check logs: `docker-compose logs`
2. Review Nginx logs: `sudo tail -f /var/log/nginx/error.log`
3. Verify all services are running: `docker-compose ps`
4. Check disk space: `df -h`

---

**Deployment Complete!** Your Crosslist Clone should now be live at your domain.