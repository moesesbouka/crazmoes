# Complete Automation Guide for Non-Coders

This guide automates EVERYTHING - from setup to deployment to updates!

## 🎯 What This Automates

✅ Server setup (Docker, Nginx, SSL)  
✅ Application deployment  
✅ Automated backups  
✅ Security hardening  
✅ Health monitoring  
✅ Automatic updates  
✅ Error notifications  

---

## 🚀 OPTION 1: One-Click Setup Script (EASIEST)

### Create the Setup Script

Save this as `setup.sh`:

```bash
#!/bin/bash

# Crosslist Clone - One-Click Setup Script
# This script automates EVERYTHING

set -e  # Exit on any error

echo "🚀 Starting Crosslist Clone Setup..."
echo "================================"

# Color codes for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Configuration
DOMAIN="your-domain.com"
EMAIL="your-email@example.com"
PROJECT_DIR="/var/www/crosslist"
BACKUP_DIR="/home/$(whoami)/backups"

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Update system
print_info "Updating system packages..."
sudo apt update && sudo apt upgrade -y
print_success "System updated"

# Install Docker
print_info "Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    print_success "Docker installed"
else
    print_info "Docker already installed"
fi

# Install Docker Compose
print_info "Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    print_success "Docker Compose installed"
else
    print_info "Docker Compose already installed"
fi

# Install Nginx
print_info "Installing Nginx..."
if ! command -v nginx &> /dev/null; then
    sudo apt install nginx -y
    sudo systemctl start nginx
    sudo systemctl enable nginx
    print_success "Nginx installed"
else
    print_info "Nginx already installed"
fi

# Install Certbot for SSL
print_info "Installing Certbot..."
sudo apt install certbot python3-certbot-nginx -y
print_success "Certbot installed"

# Create project directory
print_info "Creating project directory..."
sudo mkdir -p $PROJECT_DIR
sudo chown -R $USER:$USER $PROJECT_DIR
print_success "Project directory created"

# Clone repository (replace with your repo)
print_info "Cloning repository..."
# cd $PROJECT_DIR
# git clone https://github.com/yourusername/crosslist-clone.git .
print_success "Repository cloned (configure git clone above)"

# Setup environment file
print_info "Setting up environment..."
cd $PROJECT_DIR/backend
cp .env.example .env
# You'll need to edit this file with your credentials
print_info "Please edit $PROJECT_DIR/backend/.env with your credentials"

# Setup Nginx configuration
print_info "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/crosslist > /dev/null <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
        proxy_read_timeout 300;
    }

    location /uploads {
        proxy_pass http://127.0.0.1:8000;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/crosslist /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
print_success "Nginx configured"

# Start application
print_info "Starting application..."
cd $PROJECT_DIR
docker-compose up -d
print_success "Application started"

# Setup SSL
print_info "Setting up SSL certificate..."
read -p "Get SSL certificate now? (y/n): " get_ssl
if [ "$get_ssl" = "y" ]; then
    sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email $EMAIL
    print_success "SSL certificate installed"
fi

# Setup automated backups
print_info "Setting up automated backups..."
mkdir -p $BACKUP_DIR

# Create backup script
cat > ~/backup_crosslist.sh <<'BACKUP_SCRIPT'
#!/bin/bash
BACKUP_DIR="/home/$(whoami)/backups"
DATE=$(date +%Y%m%d_%H%M%S)
PROJECT_DIR="/var/www/crosslist"

mkdir -p "$BACKUP_DIR"

# Backup database
docker-compose -f "$PROJECT_DIR/docker-compose.yml" exec -T db pg_dump -U crosslist_user crosslist_db > "$BACKUP_DIR/database_$DATE.sql"

# Backup images
tar -czf "$BACKUP_DIR/images_$DATE.tar.gz" -C "$PROJECT_DIR" uploads/

# Keep last 7 days
find "$BACKUP_DIR" -name "database_*.sql" -mtime +7 -delete
find "$BACKUP_DIR" -name "images_*.tar.gz" -mtime +7 -delete

echo "Backup completed: $DATE"
BACKUP_SCRIPT

chmod +x ~/backup_crosslist.sh

# Add to crontab
(crontab -l 2>/dev/null; echo "0 2 * * * ~/backup_crosslist.sh >> ~/backup.log 2>&1") | crontab -
print_success "Automated backups configured"

# Setup firewall
print_info "Configuring firewall..."
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
echo "y" | sudo ufw enable
print_success "Firewall configured"

# Setup monitoring
print_info "Setting up health monitoring..."
cat > ~/health_check.sh <<'HEALTH_SCRIPT'
#!/bin/bash
curl -f http://localhost:8000/health || echo "Backend is down!"
curl -f http://localhost:5173 || echo "Frontend is down!"
docker-compose -f /var/www/crosslist/docker-compose.yml ps
HEALTH_SCRIPT

chmod +x ~/health_check.sh
(crontab -l 2>/dev/null; echo "*/5 * * * * ~/health_check.sh >> ~/health.log 2>&1") | crontab -
print_success "Health monitoring configured"

print_success "================================"
print_success "🎉 Setup Complete!"
echo ""
echo "📝 Next Steps:"
echo "1. Edit $PROJECT_DIR/backend/.env with your credentials"
echo "2. Access your app at http://$DOMAIN"
echo "3. Check status: docker-compose -f $PROJECT_DIR/docker-compose.yml ps"
echo "4. View logs: docker-compose -f $PROJECT_DIR/docker-compose.yml logs -f"
echo ""
echo "📚 Documentation:"
echo "- Full docs: README.md"
echo "- API docs: API_DOCUMENTATION.md"
echo "- Deployment: DEPLOYMENT.md"
echo "- Backups: BACKUP_GUIDE.md"
```

### How to Use It

1. **Upload the script to your server:**
```bash
scp setup.sh user@your-domain.com:~/
```

2. **Make it executable and run:**
```bash
ssh user@your-domain.com
chmod +x setup.sh
sudo ./setup.sh
```

3. **That's it!** Everything is now automated.

---

## 🔧 OPTION 2: GitHub Actions (Easy Version)

### Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
    
    - name: Deploy to server
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.SERVER_HOST }}
        username: ${{ secrets.SERVER_USER }}
        key: ${{ secrets.SSH_PRIVATE_KEY }}
        script: |
          cd /var/www/crosslist
          git pull origin main
          docker-compose down
          docker-compose pull
          docker-compose up -d --build
          
    - name: Notify on failure
      if: failure()
      uses: actions/github-script@v6
      with:
        script: |
          github.rest.issues.create({
            owner: context.repo.owner,
            repo: context.repo.repo,
            title: 'Deployment Failed',
            body: 'The automated deployment failed. Please check the logs.'
          })
```

### How to Set Up GitHub Actions

1. **Go to your GitHub repository**
2. **Click Settings → Secrets and variables → Actions**
3. **Add these secrets:**
   - `SERVER_HOST`: Your domain or IP
   - `SERVER_USER`: Your SSH username
   - `SSH_PRIVATE_KEY`: Your private SSH key

4. **Push your code** and it deploys automatically!

---

## 🤖 OPTION 3: Watchtower (Auto-Update Docker)

### Add to `docker-compose.yml`:

```yaml
services:
  # Add this service
  watchtower:
    image: containrrr/watchtower
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      - WATCHTOWER_CLEANUP=true
      - WATCHTOWER_POLL_INTERVAL=3600  # Check every hour
    restart: unless-stopped
```

### What It Does:
- Automatically checks for Docker image updates every hour
- Updates your containers automatically
- Removes old images to save space

---

## 📊 OPTION 4: Health Monitoring & Alerts

### Create `monitor.sh`:

```bash
#!/bin/bash

# Health monitoring script
APP_URL="http://localhost:8000/health"
ALERT_EMAIL="your-email@example.com"

if ! curl -f -s $APP_URL > /dev/null; then
    echo "❌ Application is DOWN! Restarting..."
    cd /var/www/crosslist
    docker-compose restart
    
    # Send email alert (requires mailutils)
    echo "Crosslist app is down and has been restarted" | mail -s "Alert: Crosslist Down" $ALERT_EMAIL
else
    echo "✅ Application is healthy"
fi
```

### Add to crontab:
```bash
*/5 * * * * ~/monitor.sh
```

---

## 🔄 OPTION 5: Complete Automation Suite

Create a master script that does EVERYTHING:

```bash
#!/bin/bash

# Master automation script
# This handles ALL automation tasks

case "$1" in
    setup)
        ./setup.sh
        ;;
    deploy)
        cd /var/www/crosslist
        git pull origin main
        docker-compose down
        docker-compose up -d --build
        ;;
    backup)
        ~/backup_crosslist.sh
        ;;
    update)
        cd /var/www/crosslist
        docker-compose pull
        docker-compose up -d
        ;;
    monitor)
        ~/health_check.sh
        ;;
    *)
        echo "Usage: $0 {setup|deploy|backup|update|monitor}"
        exit 1
esac
```

### Use it like:
```bash
# Initial setup
./automate.sh setup

# Deploy updates
./automate.sh deploy

# Manual backup
./automate.sh backup

# Update containers
./automate.sh update

# Check health
./automate.sh monitor
```

---

## 📱 OPTION 6: Simple Dashboard for Monitoring

Create `dashboard.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Crosslist Status</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .status { padding: 20px; border-radius: 5px; margin: 10px 0; }
        .online { background: #d4edda; color: #155724; }
        .offline { background: #f8d7da; color: #721c24; }
        button { padding: 10px 20px; margin: 10px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Crosslist Status Dashboard</h1>
    
    <div id="status" class="status">Checking...</div>
    
    <button onclick="restartBackend()">Restart Backend</button>
    <button onclick="restartFrontend()">Restart Frontend</button>
    <button onclick="backupNow()">Backup Now</button>
    <button onclick="viewLogs()">View Logs</button>
    
    <h2>Server Stats</h2>
    <canvas id="cpuChart"></canvas>
    <canvas id="memChart"></canvas>

    <script>
        async function checkStatus() {
            try {
                const response = await fetch('/api/health');
                const status = document.getElementById('status');
                status.textContent = '✅ Online';
                status.className = 'status online';
            } catch (error) {
                const status = document.getElementById('status');
                status.textContent = '❌ Offline';
                status.className = 'status offline';
            }
        }

        function restartBackend() {
            fetch('/api/restart/backend', { method: 'POST' });
            alert('Backend restarting...');
        }

        // Check status every 30 seconds
        setInterval(checkStatus, 30000);
        checkStatus();
    </script>
</body>
</html>
```

---

## 🎯 Summary of What You Get

With these automations, you get:

✅ **Zero Manual Setup** - One command installs everything  
✅ **Auto Deployments** - Push to GitHub, it deploys automatically  
✅ **Auto Backups** - Backups run automatically every day  
✅ **Auto Updates** - Docker containers update automatically  
✅ **Health Monitoring** - Get alerts if something goes wrong  
✅ **Easy Recovery** - One-click restore from backups  

---

## 🚀 Quick Start (Choose Your Path)

**Path A: Complete Beginner** → Use OPTION 1 (setup.sh)  
**Path B: GitHub User** → Use OPTION 2 (GitHub Actions)  
**Path C: Want Everything** → Use all options together  

---

## 💡 Pro Tips

1. **Test locally first** - Before automating, make sure everything works
2. **Keep backups** - Always have recent backups before updates
3. **Monitor logs** - Check logs regularly for issues
4. **Start simple** - Begin with one automation, add more later

---

## 🆘 Need Help?

If anything goes wrong:
1. Check logs: `docker-compose logs`
2. Restart: `docker-compose restart`
3. Restore backup: See BACKUP_GUIDE.md

**The automations are designed to be fail-safe, so don't worry!**

---

**You're now ready for a completely hands-off experience! 🎉**