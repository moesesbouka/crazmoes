# Backup & Recovery Guide

This guide covers backup strategies and recovery procedures for your Crosslist Clone.

## What Needs Backup

1. **PostgreSQL Database** - All listings, sync logs, and data
2. **Uploaded Images** - Product images stored in uploads directory
3. **Environment Configuration** - API keys and settings (.env files)
4. **Application Code** - If you make custom modifications

## Automated Backups

### Daily Backup Script

Create the backup script:

```bash
nano ~/backup_crosslist.sh
```

Add this content:

```bash
#!/bin/bash

# Configuration
BACKUP_DIR="/home/$(whoami)/crosslist_backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30
PROJECT_DIR="/var/www/crosslist"

# Create backup directory
mkdir -p "$BACKUP_DIR"

echo "Starting backup at $(date)"

# Backup PostgreSQL database
echo "Backing up database..."
docker-compose -f "$PROJECT_DIR/docker-compose.yml" exec -T db pg_dump -U crosslist_user crosslist_db > "$BACKUP_DIR/database_$DATE.sql"

# Backup uploaded images
echo "Backing up images..."
tar -czf "$BACKUP_DIR/images_$DATE.tar.gz" -C "$PROJECT_DIR" uploads/

# Backup environment files
echo "Backing up configuration..."
cp "$PROJECT_DIR/backend/.env" "$BACKUP_DIR/env_$DATE.txt"

# Create backup summary
echo "Backup Summary - $DATE" > "$BACKUP_DIR/backup_$DATE.log"
echo "Database: database_$DATE.sql" >> "$BACKUP_DIR/backup_$DATE.log"
echo "Images: images_$DATE.tar.gz" >> "$BACKUP_DIR/backup_$DATE.log"
echo "Config: env_$DATE.txt" >> "$BACKUP_DIR/backup_$DATE.log"
echo "Size: $(du -sh $BACKUP_DIR/*_$DATE.* | awk '{sum+=$1} END {print sum}')" >> "$BACKUP_DIR/backup_$DATE.log"

# Clean old backups (older than RETENTION_DAYS)
echo "Cleaning old backups..."
find "$BACKUP_DIR" -name "database_*.sql" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "images_*.tar.gz" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "env_*.txt" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "backup_*.log" -mtime +$RETENTION_DAYS -delete

echo "Backup completed at $(date)"
echo "Total backup size: $(du -sh $BACKUP_DIR | awk '{print $1}')"
```

Make it executable:
```bash
chmod +x ~/backup_crosslist.sh
```

### Schedule with Cron

Edit crontab:
```bash
crontab -e
```

Add these lines:

```bash
# Daily backup at 2 AM
0 2 * * * /home/$(whoami)/backup_crosslist.sh >> /home/$(whoami)/backup.log 2>&1

# Weekly backup on Sunday at 3 AM
0 3 * * 0 /home/$(whoami)/backup_crosslist.sh >> /home/$(whoami)/backup_weekly.log 2>&1
```

## Manual Backups

### Backup Database Only

```bash
docker-compose exec db pg_dump -U crosslist_user crosslist_db > backup.sql
```

### Backup Images Only

```bash
tar -czf images_backup.tar.gz uploads/
```

### Backup Everything

```bash
~/backup_crosslist.sh
```

## Off-site Backup

### Upload to Google Drive (using rclone)

1. Install rclone:
```bash
curl https://rclone.org/install.sh | sudo bash
```

2. Configure Google Drive:
```bash
rclone config
```

3. Upload backups:
```bash
rclone copy ~/crosslist_backups remote:crosslist-backups
```

### Upload to AWS S3 (using AWS CLI)

1. Install AWS CLI:
```bash
sudo apt install awscli -y
```

2. Configure AWS:
```bash
aws configure
```

3. Create bucket and upload:
```bash
aws s3 mb s3://your-crosslist-backups
aws s3 sync ~/crosslist_backups s3://your-crosslist-backups
```

## Recovery Procedures

### Restore Database

Stop the application:
```bash
docker-compose down
```

Restore database:
```bash
docker-compose up -d db
sleep 10
docker-compose exec -T db psql -U crosslist_user crosslist_db < backup.sql
```

Start the application:
```bash
docker-compose up -d
```

### Restore Images

```bash
tar -xzf images_backup.tar.gz -C /var/www/crosslist/
```

### Restore Environment Configuration

```bash
cp env_backup.txt /var/www/crosslist/backend/.env
```

### Full System Restore

1. Stop all services:
```bash
docker-compose down
```

2. Restore database:
```bash
docker-compose up -d db
sleep 10
docker-compose exec -T db psql -U crosslist_user crosslist_db < database_backup.sql
```

3. Restore images:
```bash
tar -xzf images_backup.tar.gz -C /var/www/crosslist/
```

4. Restore configuration:
```bash
cp env_backup.txt /var/www/crosslist/backend/.env
```

5. Start all services:
```bash
docker-compose up -d
```

## Disaster Recovery

### Server Failure Recovery

1. **Get new server** from Namecheap
2. **Install Docker & Docker Compose** (see Deployment Guide)
3. **Clone repository**:
   ```bash
   cd /var/www
   git clone <your-repo-url> crosslist
   ```
4. **Restore backups**:
   ```bash
   # Download backups from off-site storage
   # Or transfer from backup location
   
   # Restore database
   docker-compose exec -T db psql -U crosslist_user crosslist_db < database_backup.sql
   
   # Restore images
   tar -xzf images_backup.tar.gz -C /var/www/crosslist/
   
   # Restore configuration
   cp env_backup.txt /var/www/crosslist/backend/.env
   ```
5. **Start application**:
   ```bash
   docker-compose up -d
   ```
6. **Update DNS** if server IP changed

### Database Corruption Recovery

If database is corrupted:

1. **Stop application**:
   ```bash
   docker-compose down
   ```

2. **Remove corrupted data**:
   ```bash
   docker volume rm crosslist_postgres_data
   ```

3. **Start fresh database**:
   ```bash
   docker-compose up -d db
   ```

4. **Restore from backup**:
   ```bash
   docker-compose exec -T db psql -U crosslist_user crosslist_db < database_backup.sql
   ```

5. **Start application**:
   ```bash
   docker-compose up -d
   ```

## Monitoring Backups

### Check Backup Status

```bash
# List recent backups
ls -lht ~/crosslist_backups/ | head -20

# Check backup log
tail -f ~/backup.log

# Verify backup integrity
gunzip -t images_backup.tar.gz
```

### Backup Verification Script

Create verification script:

```bash
nano ~/verify_backups.sh
```

```bash
#!/bin/bash

BACKUP_DIR="/home/$(whoami)/crosslist_backups"
MAX_AGE_HOURS=26

echo "Checking backups..."

# Check if recent backup exists
LATEST_DB=$(ls -t "$BACKUP_DIR"/database_*.sql 2>/dev/null | head -1)
LATEST_IMG=$(ls -t "$BACKUP_DIR"/images_*.tar.gz 2>/dev/null | head -1)

if [ -z "$LATEST_DB" ]; then
    echo "ERROR: No database backup found!"
    exit 1
fi

if [ -z "$LATEST_IMG" ]; then
    echo "ERROR: No image backup found!"
    exit 1
fi

# Check backup age
DB_AGE=$(( $(date +%s) - $(stat -c %Y "$LATEST_DB") ))
IMG_AGE=$(( $(date +%s) - $(stat -c %Y "$LATEST_IMG") ))

DB_AGE_HOURS=$(( DB_AGE / 3600 ))
IMG_AGE_HOURS=$(( IMG_AGE / 3600 ))

if [ $DB_AGE_HOURS -gt $MAX_AGE_HOURS ]; then
    echo "WARNING: Database backup is $DB_AGE_HOURS hours old!"
fi

if [ $IMG_AGE_HOURS -gt $MAX_AGE_HOURS ]; then
    echo "WARNING: Image backup is $IMG_AGE_HOURS hours old!"
fi

# Verify file sizes
DB_SIZE=$(stat -c %s "$LATEST_DB")
IMG_SIZE=$(stat -c %s "$LATEST_IMG")

if [ $DB_SIZE -lt 1024 ]; then
    echo "ERROR: Database backup is too small ($DB_SIZE bytes)!"
    exit 1
fi

if [ $IMG_SIZE -lt 1024 ]; then
    echo "ERROR: Image backup is too small ($IMG_SIZE bytes)!"
    exit 1
fi

echo "✓ Database backup: $LATEST_DB ($(du -h "$LATEST_DB" | cut -f1))"
echo "✓ Image backup: $LATEST_IMG ($(du -h "$LATEST_IMG" | cut -f1))"
echo "Backups verified successfully!"
```

Add to cron for daily checks:
```bash
0 6 * * * /home/$(whoami)/verify_backups.sh
```

## Best Practices

1. **3-2-1 Backup Rule**:
   - 3 copies of data (production, on-site backup, off-site backup)
   - 2 different storage types (disk, cloud)
   - 1 off-site backup

2. **Regular Testing**:
   - Test restore procedures monthly
   - Verify backup integrity weekly
   - Monitor backup logs daily

3. **Security**:
   - Encrypt backups containing sensitive data
   - Use secure transfer methods (SFTP, encrypted S3)
   - Restrict backup access to authorized personnel

4. **Retention Policy**:
   - Daily backups: Keep 7 days
   - Weekly backups: Keep 4 weeks
   - Monthly backups: Keep 12 months

5. **Documentation**:
   - Document all backup procedures
   - Keep recovery procedures updated
   - Document any custom backup configurations

## Emergency Contacts

Keep this information accessible:

- **Backup Location**: /home/user/crosslist_backups
- **Off-site Storage**: [Your cloud storage details]
- **Database Password**: [Your database password]
- **Domain Registrar**: Namecheap
- **Hosting Provider**: Namecheap

---

**Remember**: A backup is only as good as your ability to restore it. Test your recovery procedures regularly!