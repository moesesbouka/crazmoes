#!/bin/bash

# Crosslist Clone - One-Click Setup Script
# This script automates EVERYTHING for beginners

set -e  # Exit on any error

echo "🚀 Starting Crosslist Clone Setup..."
echo "================================"

# Color codes for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    print_error "Please run as root (use sudo)"
    exit 1
fi

# Get user information
read -p "Enter your domain name (e.g., example.com): " DOMAIN
read -p "Enter your email for SSL certificates: " EMAIL
CURRENT_USER=$(whoami)

# Configuration
PROJECT_DIR="/var/www/crosslist"
BACKUP_DIR="/home/$CURRENT_USER/backups"

print_info "Configuration:"
echo "  Domain: $DOMAIN"
echo "  Email: $EMAIL"
echo "  User: $CURRENT_USER"
echo ""

# Confirm setup
read -p "Continue with these settings? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    print_info "Setup cancelled"
    exit 0
fi

# Step 1: Update system
print_info "Step 1/10: Updating system packages..."
apt update && apt upgrade -y
print_success "System updated"

# Step 2: Install Docker
print_info "Step 2/10: Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    usermod -aG docker $CURRENT_USER
    rm get-docker.sh
    print_success "Docker installed"
else
    print_info "Docker already installed"
fi

# Step 3: Install Docker Compose
print_info "Step 3/10: Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    print_success "Docker Compose installed"
else
    print_info "Docker Compose already installed"
fi

# Step 4: Install Nginx
print_info "Step 4/10: Installing Nginx..."
if ! command -v nginx &> /dev/null; then
    apt install nginx -y
    systemctl start nginx
    systemctl enable nginx
    print_success "Nginx installed"
else
    print_info "Nginx already installed"
fi

# Step 5: Install Certbot for SSL
print_info "Step 5/10: Installing Certbot..."
apt install certbot python3-certbot-nginx -y
print_success "Certbot installed"

# Step 6: Install additional tools
print_info "Step 6/10: Installing additional tools..."
apt install git curl ufw fail2ban -y
print_success "Additional tools installed"

# Step 7: Create project directory
print_info "Step 7/10: Creating project directory..."
mkdir -p $PROJECT_DIR
chown -R $CURRENT_USER:$CURRENT_USER $PROJECT_DIR
print_success "Project directory created"

# Step 8: Clone or setup repository
print_info "Step 8/10: Setting up application files..."
if [ -d "$PROJECT_DIR/.git" ]; then
    cd $PROJECT_DIR
    git pull origin main
    print_info "Repository updated"
else
    print_warning "Please clone your repository manually:"
    echo "  cd $PROJECT_DIR"
    echo "  git clone https://github.com/yourusername/crosslist-clone.git ."
    print_info "Or upload your files to $PROJECT_DIR"
fi

# Step 9: Setup environment file
print_info "Step 9/10: Setting up environment..."
if [ -f "$PROJECT_DIR/backend/.env.example" ]; then
    cd $PROJECT_DIR/backend
    cp .env.example .env
    
    # Generate secure password
    DB_PASSWORD=$(openssl rand -base64 32)
    
    # Update .env with secure password
    sed -i "s/crosslist_password/$DB_PASSWORD/g" .env
    
    print_success "Environment file created"
    print_info "Please edit $PROJECT_DIR/backend/.env with:"
    echo "  - Facebook credentials"
    echo "  - Mercari credentials"
    echo "  - Any other API keys"
else
    print_warning ".env.example not found, please create .env manually"
fi

# Step 10: Setup Nginx configuration
print_info "Step 10/10: Configuring Nginx..."
cat > /etc/nginx/sites-available/crosslist <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    # Frontend
    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Backend API
    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # Increase timeout for large uploads
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
        proxy_read_timeout 300;
    }

    # Uploaded images
    location /uploads {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
    }
}
EOF

ln -sf /etc/nginx/sites-available/crosslist /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
print_success "Nginx configured"

# Start application
print_info "Starting application..."
cd $PROJECT_DIR
if [ -f "docker-compose.yml" ]; then
    # Update docker-compose.yml for production
    sed -i 's/"8000:8000"/"127.0.0.1:8000:8000"/g' docker-compose.yml
    sed -i 's/"5173:5173"/"127.0.0.1:5173:5173"/g' docker-compose.yml
    
    docker-compose up -d
    print_success "Application started"
else
    print_warning "docker-compose.yml not found. Please create it first."
fi

# Setup SSL certificate
print_info "Setting up SSL certificate..."
read -p "Get SSL certificate now? (y/n): " get_ssl
if [ "$get_ssl" = "y" ]; then
    certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email $EMAIL --redirect
    print_success "SSL certificate installed"
else
    print_info "You can get SSL later by running: sudo certbot --nginx -d $DOMAIN"
fi

# Setup automated backups
print_info "Setting up automated backups..."
mkdir -p $BACKUP_DIR

cat > /home/$CURRENT_USER/backup_crosslist.sh <<BACKUP_SCRIPT
#!/bin/bash
BACKUP_DIR="/home/$CURRENT_USER/backups"
DATE=$(date +%Y%m%d_%H%M%S)
PROJECT_DIR="/var/www/crosslist"
RETENTION_DAYS=30

mkdir -p "\$BACKUP_DIR"

# Backup database
docker-compose -f "\$PROJECT_DIR/docker-compose.yml" exec -T db pg_dump -U crosslist_user crosslist_db > "\$BACKUP_DIR/database_\$DATE.sql"

# Backup images
tar -czf "\$BACKUP_DIR/images_\$DATE.tar.gz" -C "\$PROJECT_DIR" uploads/

# Backup environment
cp "\$PROJECT_DIR/backend/.env" "\$BACKUP_DIR/env_\$DATE.txt"

# Keep last RETENTION_DAYS
find "\$BACKUP_DIR" -name "database_*.sql" -mtime +\$RETENTION_DAYS -delete
find "\$BACKUP_DIR" -name "images_*.tar.gz" -mtime +\$RETENTION_DAYS -delete
find "\$BACKUP_DIR" -name "env_*.txt" -mtime +\$RETENTION_DAYS -delete

echo "Backup completed: \$DATE"
BACKUP_SCRIPT

chmod +x /home/$CURRENT_USER/backup_crosslist.sh

# Add to crontab
(crontab -l 2>/dev/null; echo "0 2 * * * /home/$CURRENT_USER/backup_crosslist.sh >> /home/$CURRENT_USER/backup.log 2>&1") | crontab -
print_success "Automated backups configured (runs daily at 2 AM)"

# Setup health monitoring
print_info "Setting up health monitoring..."
cat > /home/$CURRENT_USER/health_check.sh <<HEALTH_SCRIPT
#!/bin/bash

# Check backend health
if curl -f -s http://localhost:8000/health > /dev/null; then
    echo "\$(date): Backend is healthy" >> /home/$CURRENT_USER/health.log
else
    echo "\$(date): Backend is DOWN! Restarting..." >> /home/$CURRENT_USER/health.log
    docker-compose -f /var/www/crosslist/docker-compose.yml restart backend
fi

# Check frontend health
if curl -f -s http://localhost:5173 > /dev/null; then
    echo "\$(date): Frontend is healthy" >> /home/$CURRENT_USER/health.log
else
    echo "\$(date): Frontend is DOWN! Restarting..." >> /home/$CURRENT_USER/health.log
    docker-compose -f /var/www/crosslist/docker-compose.yml restart frontend
fi
HEALTH_SCRIPT

chmod +x /home/$CURRENT_USER/health_check.sh

# Add to crontab (check every 5 minutes)
(crontab -l 2>/dev/null; echo "*/5 * * * * /home/$CURRENT_USER/health_check.sh") | crontab -
print_success "Health monitoring configured (checks every 5 minutes)"

# Setup firewall
print_info "Configuring firewall..."
ufw allow 22
ufw allow 80
ufw allow 443
echo "y" | ufw enable
print_success "Firewall configured"

# Setup Fail2Ban
print_info "Configuring Fail2Ban..."
systemctl enable fail2ban
systemctl start fail2ban
print_success "Fail2Ban configured"

# Create easy management script
cat > /home/$CURRENT_USER/manage_crosslist.sh <<MANAGE_SCRIPT
#!/bin/bash

case "\$1" in
    start)
        docker-compose -f /var/www/crosslist/docker-compose.yml up -d
        ;;
    stop)
        docker-compose -f /var/www/crosslist/docker-compose.yml down
        ;;
    restart)
        docker-compose -f /var/www/crosslist/docker-compose.yml restart
        ;;
    logs)
        docker-compose -f /var/www/crosslist/docker-compose.yml logs -f
        ;;
    status)
        docker-compose -f /var/www/crosslist/docker-compose.yml ps
        ;;
    backup)
        /home/$CURRENT_USER/backup_crosslist.sh
        ;;
    update)
        cd /var/www/crosslist
        git pull origin main
        docker-compose down
        docker-compose pull
        docker-compose up -d --build
        ;;
    *)
        echo "Usage: \$0 {start|stop|restart|logs|status|backup|update}"
        exit 1
esac
MANAGE_SCRIPT

chmod +x /home/$CURRENT_USER/manage_crosslist.sh

# Success message
echo ""
print_success "================================"
print_success "🎉 Setup Complete!"
echo ""
echo "📝 Quick Commands:"
echo "  Start: ~/manage_crosslist.sh start"
echo "  Stop: ~/manage_crosslist.sh stop"
echo "  Restart: ~/manage_crosslist.sh restart"
echo "  Logs: ~/manage_crosslist.sh logs"
echo "  Status: ~/manage_crosslist.sh status"
echo "  Backup: ~/manage_crosslist.sh backup"
echo "  Update: ~/manage_crosslist.sh update"
echo ""
echo "🌐 Access Your App:"
echo "  HTTP: http://$DOMAIN"
echo "  HTTPS: https://$DOMAIN (after SSL)"
echo ""
echo "📊 Monitoring:"
echo "  Health logs: cat ~/health.log"
echo "  Backup logs: cat ~/backup.log"
echo ""
echo "🔧 Configuration:"
echo "  Edit: nano /var/www/crosslist/backend/.env"
echo "  Docker Compose: cd /var/www/crosslist && docker-compose ps"
echo ""
echo "📚 Documentation:"
echo "  Full docs: /var/www/crosslist/README.md"
echo "  API docs: /var/www/crosslist/API_DOCUMENTATION.md"
echo "  Deployment: /var/www/crosslist/DEPLOYMENT.md"
echo "  Backups: /var/www/crosslist/BACKUP_GUIDE.md"
echo ""
print_info "Don't forget to:"
echo "  1. Edit /var/www/crosslist/backend/.env with your API keys"
echo "  2. Get SSL certificate: sudo certbot --nginx -d $DOMAIN"
echo "  3. Check status: ~/manage_crosslist.sh status"
echo ""
print_success "Everything is automated and will run automatically!"