
// CrazyMoe FB Marketplace Importer — DB Enrich Runner
// Adds a small floating button on Marketplace pages that enriches existing Supabase rows
// by visiting each listing_url (same-origin fetch with cookies) and extracting description/condition/photos.
// v0.2

(() => {
  "use strict";

  const SUPABASE_URL = "https://sfheqjnxlkygjfohoybo.supabase.co";
  const SUPABASE_ANON_KEY =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNmaGVxam54bGt5Z2pmb2hveWJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgzNTc3NjUsImV4cCI6MjA4MzkzMzc2NX0.oWEnB48w_k_hOtYM1Ls2AHj8j-THDs_43BBzXrqPyxY";

  const TABLE = "marketplace_listings";
  const ON_CONFLICT = "account_tag,facebook_id";

  const BATCH_FETCH = 100;     // how many rows we pull from Supabase per round
  const ENRICH_DELAY_MS = 1400; // delay between FB page fetches
  const SAVE_EVERY = 10;       // upsert after N listings (reduces requests)

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const nowIso = () => new Date().toISOString();

  const decodeFbString = (s) => {
    if (typeof s !== "string") return s;
    return s
      .replace(/\\u002F/g, "/")
      .replace(/\\\//g, "/")
      .replace(/\\n/g, "\n")
      .replace(/\\r/g, "\r")
      .replace(/\\t/g, "\t")
      .replace(/\\"/g, '"')
      .replace(/\\\\/g, "\\");
  };

  const pickFirstMatch = (html, reList) => {
    for (const re of reList) {
      const m = html.match(re);
      if (m && m[1]) return decodeFbString(m[1]);
    }
    return null;
  };

  function extractImages(html) {
    const imgs = new Set();

    // escaped urls in JSON blobs
    const reEsc = /(https:\\/\\/[^"\s]+?fbcdn\.net[^"\s]+)/g;
    const reUnesc = /(https:\/\/[^"\s]+?fbcdn\.net[^"\s]+)/g;

    const add = (u) => {
      if (!u) return;
      let x = String(u);
      x = x.replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/\\+/g, "\\");
      x = x.replace(/\\u002F/g, "/");
      x = x.replace(/\\/g, "");
      // skip trackers/sprites
      if (x.includes("rsrc.php")) return;
      // keep common image extensions
      if (!/\.(jpg|jpeg|png|webp)(\?|$)/i.test(x)) return;
      imgs.add(x);
    };

    try {
      const m1 = html.match(reEsc) || [];
      for (const s of m1) add(s);
      const m2 = html.match(reUnesc) || [];
      for (const s of m2) add(s);
    } catch {}

    // also scan for <img src="...fbcdn...">
    try {
      const reImg = /<img[^>]+src=["'](https?:\/\/[^"']+fbcdn\.net[^"']+)["']/gi;
      let m;
      while ((m = reImg.exec(html))) add(m[1]);
    } catch {}

    return Array.from(imgs);
  }

  async function enrichFromListingUrl(url) {
    const res = await fetch(url, {
      credentials: "include",
      redirect: "follow",
      headers: { "Accept": "text/html" }
    });

    if (!res.ok) throw new Error(`FB fetch ${res.status}`);

    const html = await res.text();

    // quick checkpoint/login detection
    const head = html.slice(0, 12000).toLowerCase();
    if (head.includes("checkpoint") || head.includes("you must log in") || head.includes("two-factor")) {
      throw new Error("Blocked by login/checkpoint");
    }

    const description = pickFirstMatch(html, [
      /"redacted_description"\s*:\s*\{[^\}]*"text"\s*:\s*"((?:\\\\.|[^\"])*)"/,
      /"description"\s*:\s*"((?:\\\\.|[^\"])*)"/
    ]);

    const condition = pickFirstMatch(html, [
      /"condition"\s*:\s*"((?:\\\\.|[^\"])*)"/,
      /"item_condition"\s*:\s*\{[^\}]*"name"\s*:\s*"((?:\\\\.|[^\"])*)"/
    ]);

    const images = extractImages(html);

    return {
      description: description && description.trim().length ? description : null,
      condition: condition && condition.trim().length ? condition : null,
      images: images
    };
  }

  async function supabaseSelectNeedingEnrich(accountTag) {
    // Only pull rows missing description or condition.
    const url =
      `${SUPABASE_URL}/rest/v1/${TABLE}` +
      `?select=facebook_id,listing_url,description,condition,images` +
      `&account_tag=eq.${encodeURIComponent(accountTag)}` +
      `&or=(description.is.null,condition.is.null)` +
      `&limit=${BATCH_FETCH}`;

    const res = await fetch(url, {
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json",
        "Cache-Control": "no-cache"
      }
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`Supabase select failed (${res.status}): ${txt}`);
    }

    return await res.json();
  }

  async function supabaseUpsert(rows) {
    if (!rows.length) return;
    const url = `${SUPABASE_URL}/rest/v1/${TABLE}?on_conflict=${encodeURIComponent(ON_CONFLICT)}`;

    const res = await fetch(url, {
      method: "POST",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json",
        Prefer: "resolution=merge-duplicates,return=minimal"
      },
      body: JSON.stringify(rows)
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`Supabase upsert failed (${res.status}): ${txt}`);
    }
    await res.text().catch(() => "");
  }

  function getAccountFromStorage() {
    return new Promise((resolve) => {
      try {
        if (!chrome?.storage?.local) return resolve("MBFB");
        chrome.storage.local.get(["selectedAccount"], (res) => resolve(res?.selectedAccount || "MBFB"));
      } catch {
        resolve("MBFB");
      }
    });
  }

  // -------- UI ----------
  const ui = (() => {
    const box = document.createElement("div");
    box.id = "cm-db-enrich-runner";
    box.style.cssText = `
      position: fixed; bottom: 14px; right: 14px; z-index: 2147483647;
      width: 360px; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background: rgba(255,255,255,0.97); border: 1px solid rgba(0,0,0,0.15);
      border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.18); overflow: hidden;
    `;

    const header = document.createElement("div");
    header.style.cssText = `
      display:flex; align-items:center; justify-content:space-between;
      padding: 10px 12px; background: linear-gradient(135deg, #0ea5e9 0%, #2563eb 100%);
      border-bottom: 1px solid rgba(0,0,0,0.08); font-weight: 800; color: white;
    `;
    header.textContent = "DB Enrich Runner";

    const body = document.createElement("div");
    body.style.cssText = `padding: 10px 12px;`;

    const btn = document.createElement("button");
    btn.textContent = "🚀 Enrich missing description/condition";
    btn.style.cssText = `
      width:100%; padding:10px 12px; border-radius:12px;
      border:1px solid rgba(0,0,0,0.12);
      background: #111827; color:#fff; font-weight:900; cursor:pointer; font-size:12px;
    `;

    const status = document.createElement("div");
    status.style.cssText = `
      margin-top:10px; padding:10px 12px; border-radius:12px; background: rgba(0,0,0,0.04);
      border: 1px solid rgba(0,0,0,0.06); font-size: 12px; white-space: pre-wrap;
      line-height: 1.35;
    `;
    status.textContent = "Ready.";

    const logBox = document.createElement("div");
    logBox.style.cssText = `
      margin-top:10px; height: 160px; overflow:auto; padding:10px 12px; border-radius:12px;
      background: rgba(0,0,0,0.03); border: 1px solid rgba(0,0,0,0.06);
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 11px; white-space: pre-wrap;
    `;

    const stamp = () => {
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      return `[${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}]`;
    };

    const log = (msg) => {
      logBox.textContent += `${stamp()} ${msg}\n`;
      logBox.scrollTop = logBox.scrollHeight;
    };

    body.appendChild(btn);
    body.appendChild(status);
    body.appendChild(logBox);
    box.appendChild(header);
    box.appendChild(body);

    function mount() {
      if (document.getElementById(box.id)) return;
      document.documentElement.appendChild(box);
    }

    return { mount, btn, setStatus: (t) => (status.textContent = t), log, setEnabled: (on) => (btn.disabled = !on) };
  })();

  let running = false;

  async function run() {
    if (running) return;
    running = true;
    ui.setEnabled(false);

    const accountTag = await getAccountFromStorage();
    ui.setStatus(`Account: ${accountTag}\nStarting...`);
    ui.log(`Starting DB enrich for ${accountTag}`);

    let totalFetched = 0;
    let totalUpdated = 0;
    let totalErrors = 0;

    while (true) {
      let rows;
      try {
        rows = await supabaseSelectNeedingEnrich(accountTag);
      } catch (e) {
        ui.log(`ERROR: ${e.message || String(e)}`);
        break;
      }

      if (!rows || rows.length === 0) {
        ui.log("No more rows need enrichment ✅");
        break;
      }

      totalFetched += rows.length;
      ui.log(`Fetched ${rows.length} rows needing enrich (total fetched so far: ${totalFetched})`);

      const pendingUpserts = [];

      for (let i = 0; i < rows.length; i++) {
        const r = rows[i];
        const url = r.listing_url;
        const id = r.facebook_id ? String(r.facebook_id) : null;

        if (!id || !url) {
          totalErrors++;
          ui.log(`Skip row missing id/url`);
          continue;
        }

        ui.setStatus(
          `Account: ${accountTag}\n` +
          `Batch size: ${rows.length}\n` +
          `Progress: ${i + 1}/${rows.length}\n` +
          `Updated: ${totalUpdated} | Errors: ${totalErrors}`
        );

        try {
          const enriched = await enrichFromListingUrl(url);

          // Merge images (keep existing, add new)
          const prevImgs = Array.isArray(r.images) ? r.images : [];
          const newImgs = Array.isArray(enriched.images) ? enriched.images : [];
          const mergedImgs = Array.from(new Set([...prevImgs, ...newImgs])).slice(0, 60);

          const payload = {
            account_tag: accountTag,
            facebook_id: id,
            updated_at: nowIso(),
            // only fill if missing
            description: r.description ?? enriched.description ?? null,
            condition: r.condition ?? enriched.condition ?? null,
            images: mergedImgs
          };

          pendingUpserts.push(payload);
          totalUpdated++;

          if (pendingUpserts.length >= SAVE_EVERY) {
            await supabaseUpsert(pendingUpserts.splice(0, pendingUpserts.length));
            ui.log(`Upserted ${SAVE_EVERY} rows`);
          }
        } catch (e) {
          totalErrors++;
          ui.log(`Enrich error (${id}): ${e.message || String(e)}`);
        }

        await sleep(ENRICH_DELAY_MS);
      }

      // flush remaining
      try {
        if (pendingUpserts.length) {
          await supabaseUpsert(pendingUpserts);
          ui.log(`Upserted final ${pendingUpserts.length} rows in batch`);
        }
      } catch (e) {
        ui.log(`Upsert error: ${e.message || String(e)}`);
        break;
      }

      // loop again; query returns remaining missing rows
      ui.log("Batch done; checking for more...");
      await sleep(1200);
    }

    ui.setStatus(
      `DONE\nAccount: ${await getAccountFromStorage()}\nUpdated: ${totalUpdated}\nErrors: ${totalErrors}\nFetched: ${totalFetched}`
    );
    ui.setEnabled(true);
    running = false;
  }

  function shouldRunHere() {
    // Runner only on Marketplace pages to avoid clutter.
    return location.hostname.endsWith("facebook.com") && location.pathname.includes("/marketplace");
  }

  if (shouldRunHere()) {
    ui.mount();
    ui.btn.addEventListener("click", () => run().catch((e) => ui.log(`FATAL: ${e.message || String(e)}`)));
    ui.log("DB Enrich Runner loaded. Click button to enrich existing DB rows.");
  }
})();
