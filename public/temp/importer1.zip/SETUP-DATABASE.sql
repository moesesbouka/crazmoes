-- CrazyMoe FB Marketplace Importer v1.5.0
-- Complete database setup
-- Copy and paste this into Supabase SQL Editor and click RUN

-- Add missing columns
ALTER TABLE marketplace_listings 
ADD COLUMN IF NOT EXISTS condition text,
ADD COLUMN IF NOT EXISTS category text,
ADD COLUMN IF NOT EXISTS location text,
ADD COLUMN IF NOT EXISTS status text;

-- Backfill status for existing rows so counters work immediately
UPDATE marketplace_listings
SET status = COALESCE(
  status, 
  CASE 
    WHEN is_active THEN 'active' 
    ELSE 'inactive' 
  END
)
WHERE status IS NULL;

-- Done! Your dashboard counters should now work.
-- Run the importer again to populate condition/category/location for new listings.
