// CrazyMoe FB Marketplace Importer - Popup Controller

(function() {
  'use strict';

  let currentAccount = null;
  let pendingAccount = null;

  // DOM Elements
  const setupModal = document.getElementById('setup-modal');
  const setupMBFB = document.getElementById('setup-mbfb');
  const setupCMFB = document.getElementById('setup-cmfb');
  
  const accountSelect = document.getElementById('account-select');
  const accountBadge = document.getElementById('account-badge');
  const headerIcon = document.getElementById('header-icon');
  const btnGoToListings = document.getElementById('go-to-listings');
  const btnAccountIndicator = document.getElementById('btn-account-indicator');
  
  const switchModal = document.getElementById('switch-modal');
  const modalAccountName = document.getElementById('modal-account-name');
  const modalCancel = document.getElementById('modal-cancel');
  const modalConfirm = document.getElementById('modal-confirm');
  
  const lastImportEl = document.getElementById('last-import');
  const totalSavedEl = document.getElementById('total-saved');

  // Theme colors
  const themes = {
    MBFB: {
      badge: 'mbfb',
      icon: 'mbfb',
      btn: 'mbfb',
      body: 'mbfb-theme',
      color: '#3b82f6'
    },
    CMFB: {
      badge: 'cmfb',
      icon: 'cmfb',
      btn: 'cmfb',
      body: 'cmfb-theme',
      color: '#a855f7'
    }
  };

  // Initialize
  async function init() {
    try {
      // Load saved account
      const result = await chrome.storage.local.get(['selectedAccount', 'lastImport', 'totalImported']);
      
      currentAccount = result.selectedAccount || null;

      // Show setup modal if no account selected
      if (!currentAccount) {
        showSetupModal();
      } else {
        applyAccount(currentAccount, false);
      }

      // Load stats
      if (result.lastImport) {
        const date = new Date(result.lastImport.date);
        lastImportEl.textContent = `${result.lastImport.count} items`;
        lastImportEl.title = date.toLocaleString();
      } else {
        lastImportEl.textContent = '-';
      }

      totalSavedEl.textContent = result.totalImported || 0;

    } catch (error) {
      console.error('Init error:', error);
    }
  }

  // Show setup modal
  function showSetupModal() {
    setupModal.classList.add('show');
  }

  // Hide setup modal
  function hideSetupModal() {
    setupModal.classList.remove('show');
  }

  // Apply account theme and settings
  function applyAccount(account, save = true) {
    currentAccount = account;
    
    // Update select
    accountSelect.value = account;
    
    // Update badge
    accountBadge.className = `account-badge ${themes[account].badge}`;
    accountBadge.innerHTML = `<span>●</span> Currently: ${account}`;
    
    // Update header icon
    headerIcon.className = `header-icon ${themes[account].icon}`;
    
    // Update button
    btnGoToListings.className = `action-btn ${themes[account].btn}`;
    btnAccountIndicator.textContent = `Importing to: ${account}`;
    
    // Update body theme
    document.body.className = themes[account].body;
    
    // Save to storage
    if (save) {
      chrome.storage.local.set({ selectedAccount: account });
    }
  }

  // Show switch confirmation modal
  function showSwitchModal(newAccount) {
    pendingAccount = newAccount;
    modalAccountName.textContent = newAccount;
    switchModal.classList.add('show');
  }

  // Hide switch modal
  function hideSwitchModal() {
    switchModal.classList.remove('show');
    pendingAccount = null;
  }

  // Confirm account switch
  function confirmSwitch() {
    if (pendingAccount) {
      applyAccount(pendingAccount, true);
      hideSwitchModal();
    }
  }

  // Open Facebook selling page
  function openListings() {
    const url = 'https://www.facebook.com/marketplace/you/selling';
    chrome.tabs.create({ url });
  }

  // Event Listeners

  // First-time setup
  setupMBFB.addEventListener('click', () => {
    applyAccount('MBFB', true);
    hideSetupModal();
  });

  setupCMFB.addEventListener('click', () => {
    applyAccount('CMFB', true);
    hideSetupModal();
  });

  // Account switching
  accountSelect.addEventListener('change', (e) => {
    const newAccount = e.target.value;
    
    // If no current account (shouldn't happen), just set it
    if (!currentAccount) {
      applyAccount(newAccount, true);
      return;
    }
    
    // If same account, do nothing
    if (newAccount === currentAccount) {
      return;
    }
    
    // Show confirmation modal
    showSwitchModal(newAccount);
    
    // Reset select to current account (will update if confirmed)
    e.target.value = currentAccount;
  });

  // Modal actions
  modalCancel.addEventListener('click', () => {
    hideSwitchModal();
    accountSelect.value = currentAccount; // Reset select
  });

  modalConfirm.addEventListener('click', () => {
    confirmSwitch();
  });

  // Go to listings button
  btnGoToListings.addEventListener('click', () => {
    openListings();
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Escape to close modals
    if (e.key === 'Escape') {
      if (switchModal.classList.contains('show')) {
        hideSwitchModal();
        accountSelect.value = currentAccount;
      }
    }
    
    // Enter to confirm in switch modal
    if (e.key === 'Enter' && switchModal.classList.contains('show')) {
      confirmSwitch();
    }
  });

  // Refresh stats every 2 seconds when popup is open
  setInterval(async () => {
    try {
      const result = await chrome.storage.local.get(['lastImport', 'totalImported']);
      
      if (result.lastImport) {
        const date = new Date(result.lastImport.date);
        lastImportEl.textContent = `${result.lastImport.count} items`;
        lastImportEl.title = date.toLocaleString();
      }
      
      if (result.totalImported !== undefined) {
        totalSavedEl.textContent = result.totalImported;
      }
    } catch (error) {
      console.error('Stats refresh error:', error);
    }
  }, 2000);

  // Start the popup
  init();
})();
