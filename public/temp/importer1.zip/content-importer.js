// CrazyMoe FB Marketplace Importer — content-importer.js
// v1.6.3-DEEP — ONE-CLICK: Gets ALL data (photos, description, condition)
// Two modes: Quick (fast/basic) or Deep (complete/enriched)

(() => {
  "use strict";

  const EXT_VERSION = "1.6.3-DEEP";

  const SUPABASE_URL = "https://sfheqjnxlkygjfohoybo.supabase.co";
  const SUPABASE_ANON_KEY =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNmaGVxam54bGt5Z2pmb2hveWJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgzNTc3NjUsImV4cCI6MjA4MzkzMzc2NX0.oWEnB48w_k_hOtYM1Ls2AHj8j-THDs_43BBzXrqPyxY";

  const TABLE = "marketplace_listings";
  const ON_CONFLICT = "account_tag,facebook_id";

  const SAVE_BATCH_SIZE = 50;
  const SAVE_FLUSH_MS = 2500;
  const SAVE_RETRY_MAX = 5;

  const MIN_DELAY_MS = 900;
  const MAX_DELAY_MS = 1600;
  const SCROLL_STEP_PX = 1400;
  const SCROLL_JITTER_PX = 280;

  const NO_NEW_LISTINGS_GRACE_MS = 20 * 60 * 1000;
  const NO_GROWTH_GRACE_MS = 25 * 60 * 1000;
  const MAX_SWEEP_RUNTIME_MS = 45 * 60 * 1000;

  const ENRICH_DELAY_MS = 2000;
  const ENRICH_BATCH_SIZE = 300;

  // v1.6.3: Enrichment uses navigation-based GraphQL capture (reliable) instead of HTML parsing (brittle).
  // We visit each listing page, the interceptor captures full data (all photos/desc/condition), then we upsert.
  const ENRICH_STATE_KEY = "cm_enrich_state_v163";

  const DEBUG = true;

  const state = {
    running: false,
    stopRequested: false,
    accountTag: "MBFB",
    listings: new Map(),
    unique: 0,
    domAddedTotal: 0,
    gqlAddedTotal: 0,
    saved: 0,
    lastError: null,
    startTs: 0,
    lastNewTs: 0,
    lastGrowthTs: 0,
    lastScrollHeight: 0,
    scroller: null,
    flushTimer: null,
    interceptorInjected: false,
    currentView: null,
    deepMode: false,
    phase: "idle",
    enriched: 0,
    enrichErrors: 0,
    enrichTotal: 0
  };

  const log = (msg) => {
    ui.log(msg);
    if (DEBUG) console.log(`[CM Importer] ${msg}`);
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const randInt = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  const nowIso = () => new Date().toISOString();

  const ui = (() => {
    const box = document.createElement("div");
    box.id = "cm-importer-ui";
    box.style.cssText = `
      position: fixed; top: 14px; right: 14px; z-index: 2147483647;
      width: 460px; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background: rgba(255,255,255,0.97); border: 1px solid rgba(0,0,0,0.15);
      border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.18); overflow: hidden;
    `;

    const header = document.createElement("div");
    header.style.cssText = `
      display:flex; align-items:center; justify-content:space-between;
      padding: 10px 12px; background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      border-bottom: 1px solid rgba(0,0,0,0.08); font-weight: 800; color: white;
    `;

    const title = document.createElement("div");
    title.textContent = `FB Importer v${EXT_VERSION}`;
    title.style.fontSize = "13px";

    const acct = document.createElement("div");
    acct.style.cssText = `font-weight:800; font-size:12px;`;
    acct.textContent = `Account: ${state.accountTag}`;

    header.appendChild(title);
    header.appendChild(acct);

    const body = document.createElement("div");
    body.style.cssText = `padding: 10px 12px;`;

    const rowBtns = document.createElement("div");
    rowBtns.style.cssText = `display:flex; gap:10px; margin-bottom:10px;`;

    const btnQuick = document.createElement("button");
    btnQuick.textContent = "⚡ Quick";
    btnQuick.style.cssText = `
      flex:1; padding:12px 14px; border-radius:12px; border:1px solid rgba(0,0,0,0.12);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color:#fff; font-weight:900; cursor:pointer; font-size:13px;
    `;

    const btnDeep = document.createElement("button");
    btnDeep.textContent = "🧠 Deep";
    btnDeep.style.cssText = `
      flex:1; padding:12px 14px; border-radius:12px; border:1px solid rgba(0,0,0,0.12);
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color:#fff; font-weight:900; cursor:pointer; font-size:13px;
    `;

    const btnStop = document.createElement("button");
    btnStop.textContent = "⏹";
    btnStop.style.cssText = `
      width:50px; padding:12px; border-radius:12px; border:1px solid rgba(0,0,0,0.12);
      background:#fff; color:#111; font-weight:900; cursor:pointer;
    `;

    rowBtns.appendChild(btnQuick);
    rowBtns.appendChild(btnDeep);
    rowBtns.appendChild(btnStop);

    const status = document.createElement("div");
    status.style.cssText = `
      padding:10px 12px; border-radius:12px; background: rgba(0,0,0,0.04);
      border: 1px solid rgba(0,0,0,0.06); font-size: 12px; white-space: pre-wrap;
      margin-bottom: 10px; line-height: 1.35;
    `;

    const logBox = document.createElement("div");
    logBox.style.cssText = `
      height: 240px; overflow:auto; padding:10px 12px; border-radius:12px;
      background: rgba(0,0,0,0.03); border: 1px solid rgba(0,0,0,0.06);
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 11px; white-space: pre-wrap;
    `;

    body.appendChild(rowBtns);
    body.appendChild(status);
    body.appendChild(logBox);
    box.appendChild(header);
    box.appendChild(body);

    const stamp = () => {
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      return `[${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}]`;
    };

    function mount() {
      if (document.getElementById("cm-importer-ui")) return;
      document.documentElement.appendChild(box);
      setStatus("Ready - Choose mode");
      logLine(`Loaded v${EXT_VERSION}. Ready.`);
    }

    function setAccount(tag) {
      acct.textContent = `Account: ${tag}`;
    }

    function setStatus(text) {
      status.textContent = text;
    }

    function logLine(msg) {
      logBox.textContent += `${stamp()} ${msg}\n`;
      logBox.scrollTop = logBox.scrollHeight;
    }

    btnQuick.addEventListener("click", () => {
      if (state.running) return;
      state.deepMode = false;
      startImport().catch((e) => logLine(`ERROR: ${e?.message || String(e)}`));
    });

    btnDeep.addEventListener("click", () => {
      if (state.running) return;
      state.deepMode = true;
      startImport().catch((e) => logLine(`ERROR: ${e?.message || String(e)}`));
    });

    btnStop.addEventListener("click", () => {
      state.stopRequested = true;
      logLine("Stop requested.");
    });

    return { mount, setAccount, setStatus, log: logLine };
  })();

  function loadAccountFromStorage() {
    return new Promise((resolve) => {
      try {
        if (!chrome?.storage?.local) return resolve(null);
        chrome.storage.local.get(["selectedAccount"], (res) => resolve(res?.selectedAccount || null));
      } catch {
        resolve(null);
      }
    });
  }

  async function initAccount() {
    const stored = await loadAccountFromStorage();
    if (stored === "MBFB" || stored === "CMFB") state.accountTag = stored;
    ui.setAccount(state.accountTag);
  }

  function detectCurrentView() {
    const url = window.location.href;
    if (url.includes("/marketplace/you/sold")) return { name: "sold", status: "sold" };
    if (url.includes("/marketplace/you/pending")) return { name: "pending", status: "pending" };
    if (url.includes("/marketplace/you/hidden")) return { name: "hidden", status: "hidden" };
    if (url.includes("/marketplace/you/draft")) return { name: "draft", status: "draft" };
    return { name: "active", status: "active" };
  }

  function upsertListing(listing, source) {
    const id = listing?.facebook_id ? String(listing.facebook_id) : null;
    if (!id) return false;

    const key = `${state.accountTag}:${id}`;
    const existed = state.listings.has(key);
    const prev = state.listings.get(key) || {};
    
    let mergedImages = [];
    if (Array.isArray(listing.images) && listing.images.length > 0) {
      mergedImages = listing.images;
    } else if (Array.isArray(prev.images) && prev.images.length > 0) {
      mergedImages = prev.images;
    }

    state.listings.set(key, {
      ...prev,
      ...listing,
      account_tag: state.accountTag,
      facebook_id: id,
      last_seen_at: nowIso(),
      updated_at: nowIso(),
      imported_at: prev.imported_at || nowIso(),
      images: mergedImages,
      is_active: listing.is_active ?? prev.is_active ?? (listing.status === "active"),
      status: listing.status ?? prev.status ?? state.currentView?.status ?? null,
      condition: listing.condition ?? prev.condition ?? null,
      category: listing.category ?? prev.category ?? null,
      location: listing.location ?? prev.location ?? null,
      description: listing.description ?? prev.description ?? null
    });

    if (!existed) {
      state.unique++;
      state.lastNewTs = Date.now();
      if (source === "dom") state.domAddedTotal++;
      if (source === "gql") state.gqlAddedTotal++;
    }
    return !existed;
  }

  function extractItemIdFromUrl(url) {
    if (!url || typeof url !== "string") return null;
    const m = url.match(/\/marketplace\/item\/(\d+)/);
    return m ? m[1] : null;
  }

  function collectFromDom() {
    const anchors = document.querySelectorAll('a[href*="/marketplace/item/"]');
    let added = 0;

    for (const a of anchors) {
      const url = a.href;
      const id = extractItemIdFromUrl(url);
      if (!id) continue;

      const title = a.getAttribute("aria-label") || a.textContent?.trim() || "";
      if (!title || title.length < 3) continue;

      const isNew = upsertListing({
        facebook_id: id,
        title,
        listing_url: url.split("?")[0],
        is_active: true
      }, "dom");

      if (isNew) added++;
    }

    return { anchors: anchors.length, added };
  }

  function injectPageInterceptor() {
    if (state.interceptorInjected) return;
    state.interceptorInjected = true;

    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("page-graphql-interceptor.js");
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
      log("Injected page-graphql-interceptor.js");
    } catch (e) {
      log(`Failed to inject interceptor: ${e.message}`);
    }
  }

  window.addEventListener("message", (ev) => {
    try {
      if (!ev.data || typeof ev.data !== "object") return;
      if (!ev.data.__FBIMP__) return;

      if (ev.data.kind === "diag") {
        log(`(interceptor) ${ev.data.msg}`);
        return;
      }

      if (ev.data.kind === "listing" && ev.data.listing) {
        const l = ev.data.listing;
        const isActive = l.status === "active" || l.is_active === true;

        upsertListing({
          facebook_id: l.facebook_id,
          title: l.title,
          description: l.description,
          price: l.price,
          images: l.images,
          condition: l.condition,
          category: l.category,
          location: l.location,
          status: l.status,
          listing_url: l.listing_url || (l.facebook_id ? `https://www.facebook.com/marketplace/item/${l.facebook_id}/` : null),
          is_active: isActive
        }, "gql");
      }
    } catch {}
  });

  function findBestScroller() {
    const candidates = [
      document.querySelector('div[role="main"]'),
      document.querySelector('div[role="feed"]'),
      document.querySelector('main'),
      document.scrollingElement,
      document.documentElement
    ].filter(Boolean);

    let best = document.documentElement;
    let bestRoom = -1;

    for (const el of candidates) {
      try {
        const st = getComputedStyle(el);
        const oy = st.overflowY;
        const room = el.scrollHeight - el.clientHeight;

        const scrollish = (oy === "auto" || oy === "scroll" || el === document.documentElement);
        if (scrollish && room > bestRoom) {
          best = el;
          bestRoom = room;
        }
      } catch {}
    }

    return best;
  }

  function doScroll(el) {
    const step = SCROLL_STEP_PX + randInt(-SCROLL_JITTER_PX, SCROLL_JITTER_PX);
    if (el === document.documentElement || el === document.body || el === document.scrollingElement) {
      window.scrollTo(0, window.scrollY + step);
      return;
    }
    el.scrollTop = el.scrollTop + step;
  }

  async function supabaseUpsertBatch(rows) {
    const url = `${SUPABASE_URL}/rest/v1/${TABLE}?on_conflict=${encodeURIComponent(ON_CONFLICT)}`;

    const res = await fetch(url, {
      method: "POST",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json",
        Prefer: "resolution=merge-duplicates,return=minimal"
      },
      body: JSON.stringify(rows)
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`Supabase upsert failed (${res.status}): ${txt}`);
    }

    await res.text().catch(() => "");
    return null;
  }

  async function flushToSupabase() {
    const all = Array.from(state.listings.values());
    const unsaved = all.slice(state.saved, state.saved + SAVE_BATCH_SIZE);
    if (!unsaved.length) return;

    let attempt = 0;
    while (true) {
      try {
        await supabaseUpsertBatch(
          unsaved.map((x) => ({
            account_tag: x.account_tag,
            facebook_id: String(x.facebook_id),
            title: x.title ?? null,
            description: x.description ?? null,
            price: x.price ?? null,
            listing_url: x.listing_url ?? null,
            images: Array.isArray(x.images) ? x.images : [],
            condition: x.condition ?? null,
            category: x.category ?? null,
            location: x.location ?? null,
            status: x.status ?? null,
            last_seen_at: x.last_seen_at ?? nowIso(),
            imported_at: x.imported_at ?? nowIso(),
            updated_at: nowIso(),
            is_active: x.status ? (x.status === "active") : (x.is_active ?? true)
          }))
        );

        state.saved += unsaved.length;
        state.lastError = null;
        log(`Saved batch (${unsaved.length}) — saved=${state.saved}`);
        return;
      } catch (e) {
        attempt++;
        state.lastError = e?.message || String(e);
        log(`Save error attempt ${attempt}/${SAVE_RETRY_MAX}: ${state.lastError}`);
        if (attempt >= SAVE_RETRY_MAX) return;
        await sleep(800 * attempt);
      }
    }
  }

  function updateStatus(tick) {
    const view = state.currentView;
    
    if (state.phase === "sweep") {
      ui.setStatus(
        `PHASE 1: SWEEP (${view?.name})\n` +
        `Unique: ${state.unique} | Saved: ${state.saved}\n` +
        `Tick: ${tick}\n` +
        (state.deepMode ? `Next: Deep enrich all data` : `Mode: Quick only`)
      );
    } else if (state.phase === "enrich") {
      const pct = state.enrichTotal > 0 ? Math.round((state.enriched / state.enrichTotal) * 100) : 0;
      ui.setStatus(
        `PHASE 2: DEEP ENRICH\n` +
        `Progress: ${state.enriched}/${state.enrichTotal} (${pct}%)\n` +
        `Errors: ${state.enrichErrors}\n` +
        `Getting: Photos, description, condition`
      );
    }
  }

  function isItemPage() {
    return window.location.href.includes("/marketplace/item/");
  }

  function getEnrichState() {
    try {
      const raw = localStorage.getItem(ENRICH_STATE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function setEnrichState(s) {
    try {
      localStorage.setItem(ENRICH_STATE_KEY, JSON.stringify(s));
    } catch {}
  }

  function clearEnrichState() {
    try { localStorage.removeItem(ENRICH_STATE_KEY); } catch {}
  }

  async function upsertSingleToSupabase(listing) {
    // Use the same upsert endpoint, but single-row.
    await supabaseUpsertBatch([
      {
        account_tag: listing.account_tag,
        facebook_id: String(listing.facebook_id),
        title: listing.title ?? null,
        description: listing.description ?? null,
        price: listing.price ?? null,
        listing_url: listing.listing_url ?? null,
        images: Array.isArray(listing.images) ? listing.images : [],
        condition: listing.condition ?? null,
        category: listing.category ?? null,
        location: listing.location ?? null,
        status: listing.status ?? null,
        last_seen_at: listing.last_seen_at ?? nowIso(),
        imported_at: listing.imported_at ?? nowIso(),
        updated_at: nowIso(),
        is_active: listing.status ? (listing.status === "active") : (listing.is_active ?? true)
      }
    ]);
  }

  async function waitForEnrichedListing(facebookId, timeoutMs = 12000) {
    const key = `${state.accountTag}:${String(facebookId)}`;
    const startTs = Date.now();

    while (Date.now() - startTs < timeoutMs) {
      const l = state.listings.get(key);
      if (l) {
        const imgCount = Array.isArray(l.images) ? l.images.length : 0;
        const hasDesc = !!(l.description && String(l.description).trim().length);
        const hasCond = !!(l.condition && String(l.condition).trim().length);
        // We consider it enriched if we got >1 photo OR got description/condition.
        if (imgCount > 1 || hasDesc || hasCond) return l;
      }
      await sleep(250);
    }
    return null;
  }

  async function runEnrichOnItemPage(enrichState) {
    const id = extractItemIdFromUrl(window.location.href);
    if (!id) {
      enrichState.errors = (enrichState.errors || 0) + 1;
      setEnrichState(enrichState);
      return;
    }

    // Wait a moment so FB kicks off GraphQL requests.
    await sleep(1200);

    const enriched = await waitForEnrichedListing(id, 15000);
    if (enriched) {
      try {
        await upsertSingleToSupabase(enriched);
        enrichState.enriched = (enrichState.enriched || 0) + 1;
      } catch {
        enrichState.errors = (enrichState.errors || 0) + 1;
      }
    } else {
      enrichState.errors = (enrichState.errors || 0) + 1;
    }

    enrichState.index = (enrichState.index || 0) + 1;
    setEnrichState(enrichState);

    const next = enrichState.queue?.[enrichState.index];
    if (next && next.url) {
      log(`➡️ Next (${enrichState.index + 1}/${enrichState.queue.length}): ${next.title || next.id}`);
      await sleep(ENRICH_DELAY_MS);
      window.location.href = next.url;
      return;
    }

    // Done
    const total = enrichState.queue?.length || 0;
    log(`✅ Enrich complete! Enriched=${enrichState.enriched || 0}, Errors=${enrichState.errors || 0}`);
    clearEnrichState();
    if (enrichState.returnUrl) {
      await sleep(800);
      window.location.href = enrichState.returnUrl;
    }
  }

  async function maybeResumeEnrich() {
    const es = getEnrichState();
    if (!es || !es.active) return false;

    // Update UI if present
    try {
      state.phase = "enrich";
      state.enriched = es.enriched || 0;
      state.enrichErrors = es.errors || 0;
      state.enrichTotal = es.queue?.length || 0;
      updateStatus(0);
    } catch {}

    if (isItemPage()) {
      log(`Resuming enrich: ${es.index + 1}/${es.queue.length}`);
      await runEnrichOnItemPage(es);
      return true;
    }

    // If we're back on the selling page and enrich just finished, nothing to do.
    return false;
  }

  async function enrichPhase() {
    // Build a queue of listings that likely need enrichment.
    const all = Array.from(state.listings.values());
    const needs = all.filter((l) => {
      const imgCount = Array.isArray(l.images) ? l.images.length : 0;
      const hasDesc = !!(l.description && String(l.description).trim().length);
      const hasCond = !!(l.condition && String(l.condition).trim().length);
      return imgCount <= 1 || !hasDesc || !hasCond;
    });

    const queue = needs
      .filter((l) => !!l.listing_url)
      .slice(0, ENRICH_BATCH_SIZE)
      .map((l) => ({ id: String(l.facebook_id), url: l.listing_url, title: l.title || "" }));

    state.phase = "enrich";
    state.enrichTotal = queue.length;
    state.enriched = 0;
    state.enrichErrors = 0;
    updateStatus(0);

    if (!queue.length) {
      log(`Deep enrich: nothing to enrich ✅`);
      return;
    }

    log(`Starting Phase 2: Deep enrich (nav) ...`);
    log(`Queue size: ${queue.length} (of ${needs.length} needing enrichment)`);

    const es = {
      active: true,
      accountTag: state.accountTag,
      returnUrl: window.location.href,
      queue,
      index: 0,
      enriched: 0,
      errors: 0,
      startedAt: Date.now()
    };

    setEnrichState(es);

    // Navigate to first item page. The content script will resume there and upsert enriched data.
    await sleep(800);
    window.location.href = queue[0].url;
  }
  async function sweepPhase() {
    state.phase = "sweep";
    log(`Phase 1: Sweep ${state.currentView.name}...`);

    state.startTs = Date.now();
    state.lastNewTs = Date.now();
    state.lastGrowthTs = Date.now();
    state.lastScrollHeight = 0;

    state.scroller = findBestScroller();

    let tick = 0;
    const startUnique = state.unique;

    while (!state.stopRequested) {
      tick++;

      const dom = collectFromDom();

      if (state.unique > startUnique) {
        state.lastNewTs = Date.now();
      }

      if (!state.scroller || tick % 15 === 0) {
        state.scroller = findBestScroller();
      }

      const sh = state.scroller?.scrollHeight || document.documentElement.scrollHeight;
      if (sh > state.lastScrollHeight) {
        state.lastScrollHeight = sh;
        state.lastGrowthTs = Date.now();
      }

      doScroll(state.scroller || document.documentElement);

      if (tick % 25 === 0) {
        try { window.scrollBy(0, -600); } catch {}
        await sleep(250);
        try { window.scrollBy(0, 1600); } catch {}
      }

      const stallMs = Date.now() - state.lastNewTs;
      if (state.unique > startUnique && stallMs > 45_000 && stallMs < 120_000) {
        try { window.scrollTo(0, document.body.scrollHeight); } catch {}
        await sleep(600);
        try { window.scrollBy(0, -900); } catch {}
      }

      if (tick % 5 === 0) {
        const newCount = state.unique - startUnique;
        log(`${state.currentView.name} — tick ${tick}: +${newCount} this run | total=${state.unique}`);
      }

      updateStatus(tick);

      const now = Date.now();
      
      if (now - state.startTs > MAX_SWEEP_RUNTIME_MS) {
        log(`Sweep complete: max runtime`);
        break;
      }

      const hasListings = state.unique > startUnique;
      if (hasListings && now - state.lastNewTs > NO_NEW_LISTINGS_GRACE_MS) {
        log(`Sweep complete: no new for 20min`);
        break;
      }

      if (hasListings && now - state.lastGrowthTs > NO_GROWTH_GRACE_MS) {
        log(`Sweep complete: no growth`);
        break;
      }

      await sleep(randInt(MIN_DELAY_MS, MAX_DELAY_MS));
    }

    const newCount = state.unique - startUnique;
    log(`✅ Sweep complete! +${newCount} from ${state.currentView.name}`);
    return newCount;
  }

  async function startImport() {
    state.stopRequested = false;
    state.running = true;

    state.currentView = detectCurrentView();
    log(`Starting: ${state.currentView.name} (${state.deepMode ? "DEEP" : "QUICK"})`);

    injectPageInterceptor();

    if (state.flushTimer) clearInterval(state.flushTimer);
    state.flushTimer = setInterval(() => {
      flushToSupabase().catch(() => {});
    }, SAVE_FLUSH_MS);

    const sweepCount = await sweepPhase();
    await flushToSupabase();

    if (state.deepMode && !state.stopRequested) {
      log(`Starting Phase 2: Deep enrich...`);
      await enrichPhase();
    }

    state.running = false;
    state.phase = "complete";
    clearInterval(state.flushTimer);
    state.flushTimer = null;

    log(`✅ COMPLETE!`);

    ui.setStatus(
      `✅ COMPLETE!\n` +
      `View: ${state.currentView.name}\n` +
      `New: +${sweepCount}\n` +
      `Total: ${state.unique}\n` +
      `Saved: ${state.saved}\n` +
      (state.deepMode ? `Enriched: ${state.enriched}\n` : ``) +
      `\nRun on other tabs for more`
    );
  }

  (async () => {
    ui.mount();
    await initAccount();
    injectPageInterceptor();
    state.currentView = detectCurrentView();
    log(`Ready! View: ${state.currentView.name}`);
    log(`⚡ Quick = Fast (basic data)`);
    log(`🧠 Deep = Complete (all photos/desc/condition)`);

    // If Deep enrichment navigated into an item page, continue the queue automatically.
    try {
      await maybeResumeEnrich();
    } catch {}
  })();
})();
