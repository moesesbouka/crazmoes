// FB Marketplace Importer - Page Context GraphQL Interceptor
// v1.2.8 - Emits listings via postMessage so the content script can save to Supabase
(function () {
  try {
    if (window.__fbImporterInjectedV128) return;
    window.__fbImporterInjectedV128 = true;

    const EMIT_FLAG = "__FBIMP__";

    function emit(payload) {
      try {
        window.postMessage({ [EMIT_FLAG]: true, ...payload }, "*");
      } catch {}
      try {
        if (window.top && window.top !== window) {
          window.top.postMessage({ [EMIT_FLAG]: true, ...payload }, "*");
        }
      } catch {}
    }

    function cleanJsonText(t) {
      if (!t) return "";
      let s = String(t).trim();
      if (s.startsWith("for(;;);")) s = s.slice(8);
      if (s.startsWith("for (;;);")) s = s.slice("for (;;);".length);
      if (s.startsWith(")]}'")) {
        const nl = s.indexOf("\n");
        s = nl >= 0 ? s.slice(nl + 1) : s.replace(/^\)\]\}'/, "");
      }
      return s.trim();
    }

    function safeParseAny(text) {
      const t = cleanJsonText(text);
      if (!t) return null;

      try {
        return JSON.parse(t);
      } catch {}

      // NDJSON-ish
      const lines = t.split("\n").map((x) => x.trim()).filter(Boolean);
      if (lines.length <= 1) return null;

      const arr = [];
      for (const line of lines) {
        try {
          arr.push(JSON.parse(line));
        } catch {}
      }
      return arr.length ? arr : null;
    }

    function extractText(field) {
      if (!field) return "";
      if (typeof field === "string") return field.trim();
      if (typeof field === "object") {
        return String(field.text || field.value || field.name || field.display_text || "").trim();
      }
      return "";
    }

    function findTitle(obj) {
      const direct = [
        obj.title,
        obj.name,
        obj.marketplace_listing_title,
        obj.product_title,
        obj.story_title,
        obj.headline,
        obj.label,
        obj.display_name,
        obj.item_title,
        obj.product_name,
        obj.listing_title
      ];
      for (const f of direct) {
        const t = extractText(f);
        if (t && t.length > 2) return t;
      }

      const nested = [
        obj.listing?.title,
        obj.node?.title,
        obj.marketplace_listing?.title,
        obj.primary_listing?.title,
        obj.target?.title,
        obj.story?.title,
        obj.attached_story?.title,
        obj.marketplace_product_item?.title,
        obj.commerce_product_item?.title,
        obj.item?.title,
        obj.product?.title,
        obj.edge?.node?.title,
        obj.listing?.node?.title,
        obj.marketplace_listing?.node?.title
      ];
      for (const f of nested) {
        const t = extractText(f);
        if (t && t.length > 2) return t;
      }

      const descFields = [obj.description, obj.redacted_description, obj.body, obj.message];
      for (const df of descFields) {
        const d = extractText(df);
        if (d && d.length > 5) {
          const firstLine = d.split("\n")[0].trim();
          if (firstLine.length > 3) return firstLine.slice(0, 80);
        }
      }
      return null;
    }

    function extractDescription(obj) {
      return (
        extractText(obj.redacted_description) ||
        extractText(obj.description) ||
        extractText(obj.listing_description) ||
        extractText(obj.message) ||
        ""
      ) || null;
    }

    function extractPrice(obj) {
      const amt =
        obj.listing_price?.amount ??
        obj.price?.amount ??
        obj.price?.amount_with_offset ??
        obj.formatted_price?.amount ??
        null;

      if (typeof amt === "number") return amt;

      const txt =
        obj.listing_price?.formatted_amount ??
        obj.price?.formatted_amount ??
        obj.formatted_price?.text ??
        obj.price?.text ??
        obj.price ??
        null;

      if (typeof txt === "string") {
        const m = txt.replace(/,/g, "").match(/(\d+(\.\d+)?)/);
        return m ? Number(m[1]) : null;
      }
      return null;
    }

    
function extractCondition(obj) {
  return (
    extractText(obj.condition) ||
    extractText(obj.listing_condition) ||
    extractText(obj.marketplace_listing_condition) ||
    extractText(obj.item_condition) ||
    extractText(obj.itemCondition) ||
    extractText(obj.product_condition) ||
    extractText(obj.condition_display) ||
    null
  );
}

function extractCategory(obj) {
  const c =
    obj.marketplace_listing_category ||
    obj.marketplace_category ||
    obj.category ||
    obj.listing_category ||
    obj.product_category ||
    null;

  if (!c) return null;
  if (typeof c === "string") return c.trim() || null;
  return (
    extractText(c.name) ||
    extractText(c.title) ||
    extractText(c.display_name) ||
    extractText(c.id) ||
    null
  );
}

function extractLocation(obj) {
  const loc =
    obj.location ||
    obj.marketplace_location ||
    obj.seller_location ||
    obj.pickup_location ||
    obj.item_location ||
    null;

  if (!loc) return null;
  if (typeof loc === "string") return loc.trim() || null;

  return (
    extractText(loc.name) ||
    extractText(loc.text) ||
    extractText(loc.display_name) ||
    extractText(loc.city?.name) ||
    extractText(loc.reverse_geocode?.city?.name) ||
    extractText(loc.reverse_geocode?.city) ||
    null
  );
}

function extractStatus(obj) {
      if (obj.is_sold === true || obj.sold === true) return "sold";

      const soldStatus = obj.sold_status || obj.sale_status;
      if (soldStatus) {
        const ss = String(soldStatus).toUpperCase();
        if (ss === "SOLD" || ss === "COMPLETED" || ss === "CLOSED") return "sold";
      }

      if (obj.is_pending === true || obj.pending === true || obj.is_pending_sale === true) return "pending";

      const listingState = obj.listing_state || obj.marketplace_listing_state || obj.state;
      if (listingState) {
        const ls = String(listingState).toUpperCase();
        if (ls === "SOLD" || ls === "CLOSED" || ls === "COMPLETED") return "sold";
        if (ls === "PENDING" || ls === "PENDING_SALE" || ls === "PENDING_PICKUP") return "pending";
        if (ls === "DELETED" || ls === "HIDDEN" || ls === "REMOVED" || ls === "EXPIRED") return "deleted";
      }

      const visibility = obj.visibility || obj.listing_visibility;
      if (visibility) {
        const v = String(visibility).toUpperCase();
        if (v === "HIDDEN" || v === "DELETED" || v === "REMOVED") return "deleted";
      }

      return "active";
    }

    function extractImages(obj) {
      const urls = [];
      const push = (u) => {
        if (!u || typeof u !== "string") return;
        if (!u.startsWith("http")) return;
        if (urls.includes(u)) return;
        urls.push(u);
      };

      push(obj.primary_listing_photo?.image?.uri);
      push(obj.primary_photo?.image?.uri);
      push(obj.image?.uri);
      push(obj.photo?.image?.uri);

      const edges = obj.listing_photos?.edges || obj.photos?.edges || obj.images?.edges;
      if (Array.isArray(edges)) {
        for (const e of edges) push(e?.node?.image?.uri || e?.node?.uri);
      }

      if (Array.isArray(obj.photos)) {
        for (const p of obj.photos) push(p?.image?.uri || p?.uri);
      }
      if (Array.isArray(obj.listing_photos)) {
        for (const p of obj.listing_photos) push(p?.image?.uri || p?.uri);
      }
      return urls;
    }

    function normalizeUrl(obj, id) {
      const u = obj.share_uri || obj.url || obj.permalink || obj.listing_url || null;
      if (typeof u === "string" && u.includes("/marketplace/")) return u.split("?")[0];
      return id ? `https://www.facebook.com/marketplace/item/${id}/` : null;
    }

    function looksListingish(obj) {
      if (!obj || typeof obj !== "object") return false;
      const id = obj.marketplace_listing_id || obj.listing_id || obj.id;
      if (!id) return false;

      const hasTitle = !!(obj.title || obj.name || obj.marketplace_listing_title || obj.product_title);
      const hasPrice = !!(obj.listing_price || obj.price || obj.formatted_price);
      const hasPhoto = !!(obj.primary_listing_photo || obj.primary_photo || obj.listing_photos || obj.photos || obj.image);
      const hasMarketUrl =
        (typeof obj.share_uri === "string" && obj.share_uri.includes("/marketplace/")) ||
        (typeof obj.url === "string" && obj.url.includes("/marketplace/")) ||
        (typeof obj.permalink === "string" && obj.permalink.includes("/marketplace/"));

      return hasMarketUrl || ((hasTitle || hasPhoto) && hasPrice);
    }

    function deepWalkCollect(root) {
      const found = [];
      const seen = new Set();

      const walk = (node, depth) => {
        if (!node || depth > 16) return;
        if (typeof node !== "object") return;
        if (seen.has(node)) return;
        seen.add(node);

        if (looksListingish(node)) found.push(node);

        if (Array.isArray(node)) {
          for (const x of node) walk(x, depth + 1);
          return;
        }
        for (const k of Object.keys(node)) walk(node[k], depth + 1);
      };

      walk(root, 0);
      return found;
    }

    function handleGraphqlText(text) {
      const parsed = safeParseAny(text);
      if (!parsed) return;

      const payloads = Array.isArray(parsed) ? parsed : [parsed];
      for (const p of payloads) {
        const nodes = deepWalkCollect(p);
        for (const n of nodes) {
          const rawId = n.marketplace_listing_id || n.listing_id || n.id;
          if (!rawId) continue;

          const rawStr = String(rawId);
          const id = rawStr.match(/\d{5,}/)?.[0] || rawStr;

          const title = findTitle(n);
          if (!title) continue; // skip untitled like your old logic

          const status = extractStatus(n);

          emit({
            kind: "listing",
            listing: {
              facebook_id: String(id),
              title,
              description: extractDescription(n),
              price: extractPrice(n),
              images: extractImages(n),
              status,
              is_active: status === "active",
              listing_url: normalizeUrl(n, id),
              condition: extractCondition(n),
              category: extractCategory(n),
              location: extractLocation(n)
            }
          });
        }
      }
    }

    function isGraphqlUrl(url) {
      url = String(url || "");
      return url.includes("graphql") || url.includes("/api/graphql") || url.includes("graphql/");
    }

    // ---- Hook fetch ----
    const _fetch = window.fetch;
    window.fetch = async function (...args) {
      const res = await _fetch.apply(this, args);
      try {
        const url = args && args[0] ? (typeof args[0] === "string" ? args[0] : args[0].url) : "";
        if (isGraphqlUrl(url)) {
          const clone = res.clone();
          clone.text().then(handleGraphqlText).catch(() => {});
        }
      } catch {}
      return res;
    };

    // ---- Hook XHR ----
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      this.__fbimp_url = url;
      return _open.call(this, method, url, ...rest);
    };

    XMLHttpRequest.prototype.send = function (body) {
      this.addEventListener("load", function () {
        try {
          const url = this.__fbimp_url || "";
          if (isGraphqlUrl(url)) handleGraphqlText(this.responseText);
        } catch {}
      });
      return _send.call(this, body);
    };

    // one-time signal
    emit({ kind: "diag", msg: "page-graphql-interceptor v1.2.9 installed" });
  } catch (e) {
    try {
      window.postMessage({ __FBIMP__: true, kind: "diag", msg: "interceptor crashed: " + (e?.message || String(e)) }, "*");
    } catch {}
  }
})();
